<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Notif extends CI_Controller {

  public function __construct()
  {
    parent::__construct();
    $this->load->library('session');
    $this->load->database();
    $this->load->model('Dapur_model', 'dapur');

    if (!$this->session->userdata('id_admin')) {
      show_error('Unauthorized', 401);
    }
    if ($this->session->userdata('role') !== 'dapur') {
      show_error('Forbidden', 403);
    }
  }

  private function get_last_seen_id(): int
  {
    $last = (int)$this->session->userdata('dapur_last_seen_pesanan_id');
    if ($last <= 0) {
      $last = (int)$this->dapur->get_max_pesanan_id();
      $this->session->set_userdata('dapur_last_seen_pesanan_id', $last);
    }
    return $last;
  }

  public function count()
  {
    $last_seen = $this->get_last_seen_id();

    $new_count = (int)$this->dapur->count_new_pesanan_for_dapur($last_seen);

    if ($new_count > 0) {
      $max_now = (int)$this->dapur->get_max_pesanan_id();
      $this->session->set_userdata('dapur_last_seen_pesanan_id', $max_now);
    }

    return $this->output
      ->set_content_type('application/json')
      ->set_output(json_encode(['count' => $new_count]));
  }
}
