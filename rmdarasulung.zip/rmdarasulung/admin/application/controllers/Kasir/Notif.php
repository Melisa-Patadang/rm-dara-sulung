<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Notif extends CI_Controller {

  public function __construct()
  {
    parent::__construct();
    $this->load->library('session');
    $this->load->database();

    if (!$this->session->userdata('id_admin')) {
      show_error('Unauthorized', 401);
    }
    if ($this->session->userdata('role') !== 'kasir') {
      show_error('Forbidden', 403);
    }
  }

  private function get_last_seen_id(): int
  {
    $last = (int)$this->session->userdata('kasir_last_seen_status_id');
    if ($last <= 0) {
      $row = $this->db->select_max('id_status', 'mx')
        ->from('status_pesanan')
        ->where('status', 'siap_ambil')
        ->get()->row();
      $last = (int)($row->mx ?? 0);
      $this->session->set_userdata('kasir_last_seen_status_id', $last);
    }
    return $last;
  }

  public function count_ready()
  {
    $last = $this->get_last_seen_id();

    $count = (int)$this->db->from('status_pesanan')
      ->where('status', 'siap_ambil')
      ->where('id_status >', $last)
      ->count_all_results();

    if ($count > 0) {
      $row = $this->db->select_max('id_status', 'mx')
        ->from('status_pesanan')
        ->where('status', 'siap_ambil')
        ->get()->row();
      $this->session->set_userdata('kasir_last_seen_status_id', (int)($row->mx ?? $last));
    }

    return $this->output
      ->set_content_type('application/json')
      ->set_output(json_encode(['count' => $count]));
  }
}
