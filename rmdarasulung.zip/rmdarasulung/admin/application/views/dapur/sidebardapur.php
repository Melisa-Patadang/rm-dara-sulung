<aside class="sidebar" id="sidebar">
            <div class="sidebar-header" id="sidebar-toggle">
                <img src="<?= base_url('assets/picture/logodarasulung.jpeg'); ?>" class="logo">
                <div class="admin-info">
                    <p class="role">Dapur</p>
                    <p class="name">Dara Sulung</p>
                </div>
            </div>
            
            <nav class="sidebar-nav">
                <ul>
                    <li>
                        <a href="<?php echo base_url('dapur/dashboarddapur') ?>">
                            <i class="icon bi bi-ui-checks-grid"></i>
                            <span>Dashboard</span>
                        </a>
                    </li>

                </ul>
            </nav>
        </aside>