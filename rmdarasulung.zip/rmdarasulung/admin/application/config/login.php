<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Login Pelanggan</title>
  <link rel="stylesheet" href="<?= base_url('assets/member/auth.css'); ?>">
</head>
<body class="auth-body">

  <div class="auth-page">
    <div class="auth-page-title">login pelanggan</div>

    <div class="auth-yellow">
      <div class="auth-card auth-card--login">

        <div class="auth-logo-wrap">
          <img class="auth-logo" src="<?= base_url('assets/img/logo-darasulung.png'); ?>" alt="Dara Sulung">
        </div>

        <?php if ($this->session->flashdata('member_error')): ?>
          <div class="auth-alert auth-alert--danger">
            <?= $this->session->flashdata('member_error'); ?>
          </div>
        <?php endif; ?>

        <?php if ($this->session->flashdata('member_success')): ?>
          <div class="auth-alert auth-alert--success">
            <?= $this->session->flashdata('member_success'); ?>
          </div>
        <?php endif; ?>

        <form class="auth-form" method="post" action="<?= site_url('member/login'); ?>" autocomplete="off">
          <label class="auth-label">Username</label>
          <input class="auth-input" type="text" name="username" placeholder="isi username"
                 value="<?= set_value('username'); ?>" required>

          <label class="auth-label">Password</label>
          <input class="auth-input" type="password" name="password" placeholder="isi password" required>

          <button class="auth-btn" type="submit">LOGIN</button>

          <div class="auth-foot">
            doesn't have account? <a href="<?= site_url('member/register'); ?>">create one</a>
          </div>
        </form>

      </div>
    </div>
  </div>

</body>
</html>
