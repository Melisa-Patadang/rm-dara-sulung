<?php
defined('BASEPATH') OR exit('No direct script access allowed');

use Dompdf\Dompdf;
use Dompdf\Options;

class Pdf
{
    protected $ci;

    public function __construct()
    {
        $this->ci =& get_instance();

        $vendorAutoload = FCPATH . 'vendor/autoload.php';
        if (file_exists($vendorAutoload)) {
            require_once $vendorAutoload;
            return;
        }

        $manualAutoload = APPPATH . 'third_party/dompdf/autoload.inc.php';
        if (file_exists($manualAutoload)) {
            require_once $manualAutoload;
            return;
        }

        show_error('Dompdf belum terpasang. Pastikan autoload ada di vendor/autoload.php atau application/third_party/dompdf/autoload.inc.php');
    } 

    public function load_view($view, $data = [], $paper = 'A4', $orientation = 'portrait', $filename = 'document.pdf')
    {
        $html = $this->ci->load->view($view, $data, true);

        $options = new Options();
        $options->set('isRemoteEnabled', true);
        $options->set('defaultFont', 'DejaVu Sans');

        $dompdf = new Dompdf($options);
        $dompdf->loadHtml($html);
        $dompdf->setPaper($paper, $orientation);
        $dompdf->render();

        $dompdf->stream($filename, ['Attachment' => 1]);
    }
}
