<?php
  $st = strtolower(trim((string)($status ?? '')));
  $st = str_replace([' ', '-'], '_', $st);
  if ($st === 'siap_diambil') $st = 'siap_ambil';

  $step1 = ($st === 'diproses' || $st === 'siap_ambil' || $st === 'selesai');
  $step2 = ($st === 'siap_ambil' || $st === 'selesai');
  $step3 = ($st === 'selesai');

  function nf_img($foto){
    $foto = trim((string)$foto);
    // Fallback yang pasti ada (di member/assets/img)
    if ($foto === '') return base_url('assets/img/logodarasulung.jpeg');
    if (preg_match('~^https?://~i', $foto)) return $foto;
    // Jika hanya nama file (tanpa folder), arahkan ke upload admin
    if (strpos($foto, '/') === false) $foto = '../admin/uploads/menu/' . $foto;
    return base_url($foto);
  }
?>

<main class="trk-main">
  <div class="trk-wrap">

    <div class="trk-head">
      <img class="trk-brand-logo" src="<?= base_url('assets/img/logodarasulung.jpeg'); ?>" alt="Dara Sulung">
      <div class="trk-brand">RUMAH MAKAN DARA SULUNG</div>
    </div>

    <?php if ((int)($id_pesanan ?? 0) <= 0): ?>
      <div class="trk-empty" style="border:1px solid #eee; border-radius:12px; padding:14px;">
        Belum ada pesanan untuk ditampilkan.
      </div>
    <?php else: ?>

    <!-- Progress -->
    <div class="trk-progress">
      <div class="trk-step <?= $step1?'active':''; ?>">
        <div class="trk-ico"><i class="bi bi-arrow-repeat"></i></div>
        <div class="trk-label">Diproses</div>
      </div>

      <div class="trk-line <?= $step2?'active':''; ?>"></div>

      <div class="trk-step <?= $step2?'active':''; ?>">
        <div class="trk-ico"><i class="bi bi-box-seam"></i></div>
        <div class="trk-label">Siap diambil</div>
      </div>

      <div class="trk-line <?= $step3?'active':''; ?>"></div>

      <div class="trk-step <?= $step3?'active':''; ?>">
        <div class="trk-ico"><i class="bi bi-check2"></i></div>
        <div class="trk-label">Selesai</div>
      </div>
    </div>

    <!-- Timeline -->
    <div class="trk-card">
      <table class="trk-table">
        <thead>
          <tr>
            <th>Waktu</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($timeline)): ?>
            <tr>
              <td>-</td>
              <td>Status belum tercatat.</td>
            </tr>
          <?php else: ?>
            <?php foreach ($timeline as $t): ?>
              <?php
                $w = (string)($t['waktu'] ?? '');
                $label = (string)($t['status_label'] ?? ($t['status'] ?? ''));
                // biar mirip screenshot: hanya jam menit
                $jam = $w;
                if ($w !== '' && preg_match('/\b(\d{2}):(\d{2})\b/', $w, $m)) {
                  $jam = $m[1].'.'.$m[2];
                }
              ?>
              <tr>
                <td><?= htmlspecialchars($jam); ?></td>
                <td>Pesanan "<?= htmlspecialchars($label); ?>"</td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>

    <!-- Items -->
    <div class="trk-items">
      <?php if (empty($items)): ?>
        <div class="trk-empty">Item pesanan tidak ditemukan.</div>
      <?php else: ?>
        <?php foreach ($items as $it): ?>
          <?php
            $nama = (string)($it['nama'] ?? 'Item');
            $qty  = (int)($it['qty'] ?? 1);
            $img  = nf_img($it['foto'] ?? '');
          ?>
          <div class="trk-item">
            <img class="trk-item-img" src="<?= $img; ?>" alt="<?= htmlspecialchars($nama); ?>">
            <div class="trk-item-name"><?= htmlspecialchars($nama); ?> <?= (int)$qty; ?>x</div>
          </div>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>

    <!-- Actions -->
    <div class="trk-actions">
      <div class="trk-done <?= $step3?'is-done':''; ?>">
        <i class="bi bi-check2"></i>
        <span>PESANAN SELESAI</span>
      </div>

      <button type="button" class="trk-ok" data-rm-notif-close>oke</button>
    </div>

    <?php endif; ?>

  </div>
</main>

<style>
  /* Ini sengaja dipertahankan 1 file seperti contoh kamu (biar kodenya "modelnya" sama) */
  .trk-main{ background:#fff; padding:26px 0 60px; }
  .trk-wrap{ width:min(920px, calc(100% - 32px)); margin:0 auto; }

  .trk-head{ display:flex; align-items:center; justify-content:space-between; gap:12px; margin:10px 0 18px; }
  .trk-back{ text-decoration:none; color:#111; font-weight:600; background:transparent; border:none; padding:0; cursor:pointer; }
  .trk-brand{ font-weight:800; letter-spacing:.6px; }

  .trk-progress{ display:flex; align-items:center; justify-content:center; gap:12px; margin:18px 0 26px; }
  .trk-step{ display:flex; flex-direction:column; align-items:center; gap:8px; min-width:110px; }
  .trk-ico{ width:48px; height:48px; border-radius:50%; display:flex; align-items:center; justify-content:center;
            background:#f3f3f3; color:#777; font-size:20px; }
  .trk-step.active .trk-ico{ background:#d07c1e; color:#fff; }
  .trk-label{ font-size:14px; font-weight:700; }
  .trk-line{ flex:1; height:4px; background:#f0d3a5; border-radius:999px; max-width:160px; }
  .trk-line.active{ background:#d07c1e; }

  .trk-card{ background:#fff3af; border-radius:10px; padding:10px 12px; }
  .trk-table{ width:100%; border-collapse:collapse; }
  .trk-table th{ text-align:left; font-size:13px; padding:8px; }
  .trk-table td{ padding:8px; font-size:13px; }

  .trk-items{ margin-top:16px; border:1px solid #eee; border-radius:10px; padding:10px; }
  .trk-item{ display:flex; align-items:center; gap:10px; padding:8px 6px; }
  .trk-item + .trk-item{ border-top:1px solid #f0f0f0; }
  .trk-item-img{ width:26px; height:26px; border-radius:6px; object-fit:cover; }
  .trk-item-name{ font-weight:700; }
  .trk-empty{ padding:12px; opacity:.8; }

  .trk-actions{ display:flex; justify-content:space-between; gap:12px; margin-top:18px; }
  .trk-done{ flex:1; border:1px solid #eee; border-radius:10px; padding:14px 14px; display:flex; align-items:center; gap:10px;
             justify-content:center; font-weight:800; letter-spacing:.4px; background:#fff; }
  .trk-done i{ font-size:20px; color:#d07c1e; }
  .trk-done.is-done{ background:#fff; }
  .trk-ok{ width:140px; border-radius:0; background:#a8d6ee; color:#111; text-decoration:none;
           display:flex; align-items:center; justify-content:center; font-weight:800; border:none; cursor:pointer; }
  .trk-ok:hover{ background:#87c6e4; }

  @media (max-width:640px){
    .trk-progress{ gap:8px; }
    .trk-step{ min-width:96px; }
    .trk-line{ max-width:90px; }
    .trk-actions{ flex-direction:column; }
    .trk-ok{ width:100%; height:48px; }
  }
</style>
