<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Login</title>
  <link rel="stylesheet" href="<?= base_url('assets/member/member.css'); ?>">
</head>
<body class="mb-body">

  <div class="mb-yellow">
    <div class="mb-card mb-card--login">

      <div class="mb-logo-wrap">
        <img class="mb-logo" src="<?= base_url('assets/img/logodarasulung.jpeg'); ?>" alt="Dara Sulung">
      </div>

      <?php if ($this->session->flashdata('member_error')): ?>
        <div class="mb-alert mb-alert--danger"><?= $this->session->flashdata('member_error'); ?></div>
      <?php endif; ?>

      <?php if ($this->session->flashdata('member_success')): ?>
        <div class="mb-alert mb-alert--success"><?= $this->session->flashdata('member_success'); ?></div>
      <?php endif; ?>

      <form class="mb-form" method="post" action="<?= site_url('login'); ?>" autocomplete="off">
        <label class="mb-label">Username</label>
        <input class="mb-input" type="text" name="username" placeholder="isi username"
               value="<?= set_value('username'); ?>" required>

        <label class="mb-label">Password</label>
        <input class="mb-input" type="password" name="password" placeholder="isi password" required>
        <div class="mb-foot" style="margin-top:12px;">
  
</div>


        <button class="mb-btn" type="submit">LOGIN</button>

        <div class="mb-foot">
          doesn't have account? <a href="<?= site_url('register'); ?>">create one</a>
        </div>
      </form>

    </div>
  </div>

</body>
</html>
