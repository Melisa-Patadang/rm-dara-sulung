<main>

  <!-- HERO (CAROUSEL) -->
  <section class="rm-hero" id="rmHero">

    <!-- SLIDES -->
    <div class="rm-hero-track" id="rmHeroTrack">

      <div class="rm-hero-slide is-active">
        <img src="<?= base_url('assets/img/hero1.jpg'); ?>" alt="Hero 1">
      </div>

      <div class="rm-hero-slide">
        <img src="<?= base_url('assets/img/hero2.jpg'); ?>" alt="Hero 2">
      </div>

      <div class="rm-hero-slide">
        <img src="<?= base_url('assets/img/hero3.jpg'); ?>" alt="Hero 3">
      </div>

    </div>

    <!-- overlay -->
    <div class="rm-hero-overlay"></div>

    <!-- content text -->
    <div class="rm-hero-content">
      <div class="rm-wrap">
        <div class="rm-hero-box">
          <h1 class="rm-hero-title rm-anim-hero-title" id="rmHeroTitle">RUMAH MAKAN DARA SULUNG</h1>
          <div class="rm-hero-line"></div>

          <p class="rm-hero-desc rm-anim-hero-desc" id="rmHeroDesc">
            Masakan rumahan dengan rasa konsisten, disajikan hangat setiap hari.
          </p>
        </div>
      </div>
    </div>

    <!-- dots -->
    <div class="rm-hero-dots" id="rmHeroDots">
      <button type="button" class="rm-hero-dot active" data-i="0" aria-label="Slide 1"></button>
      <button type="button" class="rm-hero-dot" data-i="1" aria-label="Slide 2"></button>
      <button type="button" class="rm-hero-dot" data-i="2" aria-label="Slide 3"></button>
    </div>

  </section>


  <!-- KATEGORI -->
  <section class="rm-section">
    <div class="rm-wrap">
      <h3 class="rm-title">KATEGORI</h3>

      <div class="rm-cat-row">
        <a class="rm-cat" href="<?= site_url('menu?kategori=makanan'); ?>">
          <div class="rm-cat-circle">
            <img src="<?= base_url('assets/img/makanan.png'); ?>" alt="Makanan">
          </div>
          <div class="rm-cat-label">MAKANAN</div>
        </a>

        <a class="rm-cat" href="<?= site_url('menu?kategori=minuman'); ?>">
          <div class="rm-cat-circle">
            <img src="<?= base_url('assets/img/minuman.png'); ?>" alt="Minuman">
          </div>
          <div class="rm-cat-label">MINUMAN</div>
        </a>

        <a class="rm-cat" href="<?= site_url('menu?kategori=cemilan'); ?>">
          <div class="rm-cat-circle">
            <img src="<?= base_url('assets/img/cemilan.png'); ?>" alt="Cemilan">
          </div>
          <div class="rm-cat-label">CEMILAN</div>
        </a>
      </div>
    </div>
  </section>


  <section class="rm-section">
    <div class="rm-wrap">
      <h3 class="rm-title">KUALITAS RUMAH MAKAN DARA SULUNG</h3>

      
      <div class="rm-quality-row rm-reveal-group">
        <div class="rm-quality-text rm-reveal rm-from-left">
          Kami menjaga kualitas dari hal paling dasar: bahan dan proses. Bahan baku dipilih dalam kondisi segar, lalu diolah dengan cara yang konsisten agar rasa selalu stabil dari hari ke hari. Setiap menu dimasak dengan takaran bumbu yang terukur, bukan sekadar “kira-kira”, supaya hasilnya tetap sama enaknya—baik saat kamu makan di tempat maupun saat dibawa pulang.
        </div>

        <div class="rm-quality-img rm-reveal rm-from-right">
          <img src="<?= base_url('assets/img/FOOD1.png'); ?>" alt="Quality 1">
        </div>
      </div>

      <div class="rm-midline"></div>

      <div class="rm-quality-row reverse rm-reveal-group">
        <div class="rm-quality-img rm-reveal rm-from-left">
          <img src="<?= base_url('assets/img/FOOD2.png'); ?>" alt="Quality 2">
        </div>

        <div class="rm-quality-text rm-reveal rm-from-right">
          Kualitas juga terasa dari cara kami melayani. Kami berusaha membuat proses pemesanan lebih cepat, lebih rapi, dan lebih nyaman—tanpa mengorbankan rasa. Kalau kamu sedang buru-buru, kamu tetap bisa dapat makanan hangat dengan waktu tunggu yang masuk akal. Kalau kamu ingin makan santai, suasana dibuat tetap nyaman dan tidak bikin ribet.
        </div>
      </div>

    </div>
  </section>

</main>



<script>
(function(){
  const hero = document.getElementById('rmHero');
  const track = document.getElementById('rmHeroTrack');
  const dotsWrap = document.getElementById('rmHeroDots');
  const titleEl = document.getElementById('rmHeroTitle');
  const descEl  = document.getElementById('rmHeroDesc');

  if(!hero || !track || !dotsWrap || !titleEl || !descEl) return;

  const slides = Array.from(track.querySelectorAll('.rm-hero-slide'));
  const dots = Array.from(dotsWrap.querySelectorAll('.rm-hero-dot'));

  const userName = "<?= addslashes(htmlspecialchars($nama ?: 'VELO')); ?>";

 
  const copy = [
    {
      title: "RUMAH MAKAN DARA SULUNG",
      desc: `Masakan rumahan dengan rasa konsisten, disajikan hangat setiap hari. Selamat datang, ${userName}.`
    },
    {
      title: "BAHAN SEGAR, DIOLAH SETIAP PAGI",
      desc: "Kami pilih bahan terbaik dan masak dengan standar yang sama—biar kamu tenang."
    },
    {
      title: "CEPAT, RAPI, DAN NYAMAN",
      desc: "Makan di tempat atau bungkus—pelayanan tetap sigap, rasa tetap juara."
    }
  ];

  let idx = 0;
  let timer = null;

  function replayTextAnim(){
    titleEl.classList.remove('rm-anim-hero-title');
    void titleEl.offsetWidth;
    titleEl.classList.add('rm-anim-hero-title');

    descEl.classList.remove('rm-anim-hero-desc');
    void descEl.offsetWidth;
    descEl.classList.add('rm-anim-hero-desc');
  }

  function setCopy(i){
    const data = copy[i] || copy[0];
    titleEl.textContent = data.title;
    descEl.textContent  = data.desc;
  }

  function go(i){
    idx = (i + slides.length) % slides.length;

    slides.forEach((s, k) => s.classList.toggle('is-active', k === idx));
    dots.forEach((d, k) => d.classList.toggle('active', k === idx));

    setCopy(idx);
    replayTextAnim();
  }

  function start(){
    stop();
    timer = setInterval(() => go(idx + 1), 4000);
  }

  function stop(){
    if(timer){
      clearInterval(timer);
      timer = null;
    }
  }

  dotsWrap.addEventListener('click', (e) => {
    const btn = e.target.closest('.rm-hero-dot');
    if(!btn) return;

    const i = parseInt(btn.getAttribute('data-i'), 10);
    if(Number.isFinite(i)){
      go(i);
      start();
    }
  });

  hero.addEventListener('mouseenter', stop);
  hero.addEventListener('mouseleave', start);

  go(0);
  start();
})();
</script>


<script>
(function(){
  const items = document.querySelectorAll('.rm-reveal');
  if(!items.length) return;

  // fallback kalau browser lama
  if(!('IntersectionObserver' in window)){
    items.forEach(el => el.classList.add('rm-in'));
    return;
  }

  const io = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if(entry.isIntersecting){
        entry.target.classList.add('rm-in');
        io.unobserve(entry.target); // muncul sekali saja
      }
    });
  }, {
    root: null,
    threshold: 0.18
  });

  items.forEach(el => io.observe(el));
})();
</script>
