<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Register</title>
  <link rel="stylesheet" href="<?= base_url('assets/member/member.css'); ?>">
</head>
<body class="mb-body">

  <div class="mb-yellow">
    <div class="mb-card mb-card--register">

      <div class="mb-split">
        <!-- kiri form -->
        <div class="mb-left">
          <div class="mb-head">REGISTER</div>

          <?php if ($this->session->flashdata('member_error')): ?>
            <div class="mb-alert mb-alert--danger"><?= $this->session->flashdata('member_error'); ?></div>
          <?php endif; ?>

          <form class="mb-form" method="post" action="<?= site_url('register'); ?>" autocomplete="off">

            <label class="mb-label">Username</label>
            <input class="mb-input" type="text" name="username" placeholder="isi username"
                   value="<?= set_value('username'); ?>" required>

            <label class="mb-label">Nama</label>
            <input class="mb-input" type="text" name="nama_user" placeholder="isi nama lengkap"
                   value="<?= set_value('nama_user'); ?>" required>

            <label class="mb-label">E-mail</label>
            <input class="mb-input" type="email" name="email" placeholder="isi alamat e-mail"
                   value="<?= set_value('email'); ?>" required>

            <label class="mb-label">No wa</label>
            <input class="mb-input" type="text" name="nomor" placeholder="isi nomor whatsapp"
                   value="<?= set_value('nomor'); ?>" required>

            <label class="mb-label">Password</label>
            <input class="mb-input" type="password" name="password" placeholder="isi password" required>

            <button class="mb-btn mb-btn--reg" type="submit">Register</button>

            <div class="mb-foot">
              already have account? <a href="<?= site_url('login'); ?>">login</a>
            </div>
          </form>
        </div>
        <div class="mb-right">
          <img class="mb-right-img" src="<?= base_url('assets/img/regis.png'); ?>" alt="Food">
        </div>
      </div>

    </div>
  </div>

</body>
</html>
  