<main class="rm-menu-page">
  <div class="rm-wrap rm-menu-wrap">

    <div class="rm-menu-layout">

      <!-- LEFT: LIST MENU -->
      <section class="rm-menu-main">

        <div class="rm-menu-head">
          <a class="rm-back" href="<?= site_url('member/dashboard'); ?>">&lt; Back</a>

          <form class="rm-search" method="get" action="<?= site_url('menu/0'); ?>">
            <input type="hidden" name="kategori" value="<?= htmlspecialchars((string)$kategori); ?>">
            <input
              class="rm-search-input"
              type="text"
              name="q"
              value="<?= htmlspecialchars((string)$q); ?>"
              placeholder="Cari menu..."
              autocomplete="off"
            >
            <button class="rm-search-btn" type="submit" aria-label="Cari">🔍</button>
          </form>

          <div class="rm-pills">
            <a class="rm-pill <?= ((string)$kategori==='makanan')?'active':''; ?>" href="<?= site_url('menu/0?kategori=makanan'); ?>">Makanan</a>
            <a class="rm-pill <?= ((string)$kategori==='minuman')?'active':''; ?>" href="<?= site_url('menu/0?kategori=minuman'); ?>">Minuman</a>
            <a class="rm-pill <?= ((string)$kategori==='cemilan')?'active':''; ?>" href="<?= site_url('menu/0?kategori=cemilan'); ?>">Cemilan</a>
          </div>
        </div>

    
        <div class="rm-menu-grid">
          <?php if (empty($left_items)): ?>
            <div class="rm-empty">Menu tidak ditemukan.</div>
          <?php else: ?>
            <?php foreach($left_items as $m): ?>
              <?php
                $foto = trim((string)($m['foto'] ?? ''));
                if ($foto === '') $foto = 'assets/img/placeholder.jpg';
                $img  = (preg_match('~^https?://~i', $foto)) ? $foto : base_url($foto);
              ?>
              <article class="rm-card">
                <div class="rm-card-imgwrap">
                  <img class="rm-card-img" src="<?= $img; ?>" alt="<?= htmlspecialchars((string)$m['nama_menu']); ?>">
                </div>

                <div class="rm-card-body">
                  <div class="rm-card-title"><?= htmlspecialchars((string)$m['nama_menu']); ?></div>
                  <div class="rm-card-desc"><?= htmlspecialchars((string)($m['deskripsi'] ?? '')); ?></div>
                  <div class="rm-card-price">Rp. <?= number_format((int)($m['harga'] ?? 0), 0, ',', '.'); ?></div>

                  <button
                    type="button"
                    class="rm-btn-add"
                    data-id="<?= (int)($m['id_menu'] ?? 0); ?>"
                  >
                    pesan
                  </button>
                </div>
              </article>
            <?php endforeach; ?>
          <?php endif; ?>
        </div>
      </section>

  
      <aside class="rm-menu-side">


        <div class="rm-cart-box" id="rmCartBox">
          <div class="rm-cart-title">KERANJANG</div>

          <div class="rm-cart-list" id="rmCartList">
            <?php if (empty($cart['items'])): ?>
              <div class="rm-cart-empty">Keranjang masih kosong.</div>
            <?php else: ?>
              <?php foreach($cart['items'] as $it): ?>
                <div class="rm-cart-item" data-id="<?= (int)$it['id_menu']; ?>">
                  <div class="rm-cart-qty">
                    <button type="button" class="rm-qty-btn rm-qty-minus">-</button>
                    <input class="rm-qty-input" type="number" min="1" value="<?= (int)$it['qty']; ?>">
                    <button type="button" class="rm-qty-btn rm-qty-plus">+</button>
                  </div>

                  <div class="rm-cart-name"><?= htmlspecialchars((string)$it['nama']); ?></div>

                  <button type="button" class="rm-cart-remove" title="Hapus">×</button>
                </div>
              <?php endforeach; ?>
            <?php endif; ?>
          </div>

          <div class="rm-cart-footer">
            <div class="rm-cart-total">
              <span>Total pemesanan:</span>
              <b id="rmCartTotalQty"><?= (int)($cart['total_qty'] ?? 0); ?></b>
            </div>

            <button
              type="button"
              class="rm-cart-order"
              id="rmCartOrderBtn"
              <?= ((int)($cart['total_qty'] ?? 0) <= 0) ? 'disabled' : ''; ?>
            >
              Pesan
            </button>

            <button
              type="button"
              class="rm-cart-clear"
              id="rmCartClearBtn"
              <?= ((int)($cart['total_qty'] ?? 0) <= 0) ? 'disabled' : ''; ?>
            >
              Kosongkan
            </button>
          </div>
        </div>

        <div class="rm-sidecards">
          <?php if (!empty($right_items)): ?>
            <?php foreach($right_items as $m): ?>
              <?php
                $foto = trim((string)($m['foto'] ?? ''));
                if ($foto === '') $foto = 'assets/img/placeholder.jpg';
                $img  = (preg_match('~^https?://~i', $foto)) ? $foto : base_url($foto);
              ?>
              <article class="rm-card rm-card--side">
                <div class="rm-card-imgwrap">
                  <img class="rm-card-img" src="<?= $img; ?>" alt="<?= htmlspecialchars((string)$m['nama_menu']); ?>">
                </div>

                <div class="rm-card-body">
                  <div class="rm-card-title"><?= htmlspecialchars((string)$m['nama_menu']); ?></div>
                  <div class="rm-card-desc"><?= htmlspecialchars((string)($m['deskripsi'] ?? '')); ?></div>
                  <div class="rm-card-price">Rp. <?= number_format((int)($m['harga'] ?? 0), 0, ',', '.'); ?></div>

                  <button
                    type="button"
                    class="rm-btn-add"
                    data-id="<?= (int)($m['id_menu'] ?? 0); ?>"
                  >
                    pesan
                  </button>
                </div>
              </article>
            <?php endforeach; ?>
          <?php else: ?>
            <div class="rm-empty">Tidak ada menu tambahan.</div>
          <?php endif; ?>
        </div>

      </aside>

    </div>

  </div>
  <?php if (!empty($pagination)): ?>
          <div class="rm-paging">
            <?= $pagination; ?>
          </div>
        <?php endif; ?>

</main>


<script>
(function(){
  const URL_ADD    = "<?= site_url('menu/cart/add'); ?>";
  const URL_UPDATE = "<?= site_url('menu/cart/update'); ?>";
  const URL_REMOVE = "<?= site_url('menu/cart/remove'); ?>";
  const URL_CLEAR  = "<?= site_url('menu/cart/clear'); ?>";

  const cartList   = document.getElementById('rmCartList');
  const totalQtyEl = document.getElementById('rmCartTotalQty');
  const orderBtn   = document.getElementById('rmCartOrderBtn');
  const clearBtn   = document.getElementById('rmCartClearBtn');

  function setDisabledByQty(totalQty){
    const dis = !(totalQty > 0);
    if(orderBtn) orderBtn.disabled = dis;
    if(clearBtn) clearBtn.disabled = dis;
  }

  function renderCart(cart){
    const items = (cart && cart.items) ? cart.items : [];
    const totalQty = (cart && cart.total_qty) ? cart.total_qty : 0;

    if(totalQtyEl) totalQtyEl.textContent = totalQty;
    setDisabledByQty(totalQty);

    if(!cartList) return;

    if(items.length === 0){
      cartList.innerHTML = '<div class="rm-cart-empty">Keranjang masih kosong.</div>';
      return;
    }

    cartList.innerHTML = items.map(it => `
      <div class="rm-cart-item" data-id="${it.id_menu}">
        <div class="rm-cart-qty">
          <button type="button" class="rm-qty-btn rm-qty-minus">-</button>
          <input class="rm-qty-input" type="number" min="1" value="${it.qty}">
          <button type="button" class="rm-qty-btn rm-qty-plus">+</button>
        </div>
        <div class="rm-cart-name">${escapeHtml(it.nama)}</div>
        <button type="button" class="rm-cart-remove" title="Hapus">×</button>
      </div>
    `).join('');
  }

  function escapeHtml(str){
    return String(str || '')
      .replaceAll('&','&amp;')
      .replaceAll('<','&lt;')
      .replaceAll('>','&gt;')
      .replaceAll('"','&quot;')
      .replaceAll("'","&#039;");
  }

  async function post(url, data){
    const fd = new FormData();
    Object.keys(data || {}).forEach(k => fd.append(k, data[k]));
    const res = await fetch(url, { method:'POST', body: fd });
    return await res.json();
  }

  document.addEventListener('click', async (e) => {
    const btn = e.target.closest('.rm-btn-add');
    if(!btn) return;

    const id = parseInt(btn.getAttribute('data-id'), 10);
    if(!Number.isFinite(id) || id <= 0) return;

    btn.disabled = true;
    try{
      const out = await post(URL_ADD, { id_menu: id, qty: 1 });
      if(out && out.ok){
        renderCart(out.cart);
      }
    } finally {
      btn.disabled = false;
    }
  });

  cartList && cartList.addEventListener('click', async (e) => {
    const row = e.target.closest('.rm-cart-item');
    if(!row) return;

    const id = parseInt(row.getAttribute('data-id'), 10);
    if(!Number.isFinite(id) || id <= 0) return;

    const input = row.querySelector('.rm-qty-input');
    let qty = parseInt(input ? input.value : '1', 10);
    if(!Number.isFinite(qty) || qty <= 0) qty = 1;

    if(e.target.closest('.rm-qty-plus')){
      qty += 1;
      const out = await post(URL_UPDATE, { id_menu: id, qty: qty });
      if(out && out.ok) renderCart(out.cart);
      return;
    }

    if(e.target.closest('.rm-qty-minus')){
      qty -= 1;
      const out = await post(URL_UPDATE, { id_menu: id, qty: qty });
      if(out && out.ok) renderCart(out.cart);
      return;
    }

    if(e.target.closest('.rm-cart-remove')){
      const out = await post(URL_REMOVE, { id_menu: id });
      if(out && out.ok) renderCart(out.cart);
      return;
    }
  });

  cartList && cartList.addEventListener('change', async (e) => {
    const input = e.target.closest('.rm-qty-input');
    if(!input) return;

    const row = e.target.closest('.rm-cart-item');
    if(!row) return;

    const id = parseInt(row.getAttribute('data-id'), 10);
    let qty = parseInt(input.value, 10);
    if(!Number.isFinite(qty) || qty <= 0) qty = 1;

    const out = await post(URL_UPDATE, { id_menu: id, qty: qty });
    if(out && out.ok) renderCart(out.cart);
  });

  const URL_CHECKOUT = "<?= site_url('member/isi_pesanan'); ?>";

orderBtn && orderBtn.addEventListener('click', () => {
  window.location.href = URL_CHECKOUT;
});


  clearBtn && clearBtn.addEventListener('click', async () => {
    const out = await post(URL_CLEAR, {});
    if(out && out.ok) renderCart(out.cart);
  });

})();
</script>
