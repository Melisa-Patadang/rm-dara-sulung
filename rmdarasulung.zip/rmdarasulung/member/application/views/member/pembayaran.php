<main class="pb-main">
      <div style="margin-bottom:14px;">
      <a class="ip-back" href="<?= site_url('member/menu'); ?>">&lt; Back</a>
    </div>

  <section class="pb-card">

    <?php if($this->session->flashdata('pesan_gagal')): ?>
      <div class="pb-alert pb-alert--danger">
        <?= $this->session->flashdata('pesan_gagal'); ?>
      </div>
    <?php endif; ?>

    <?php if($this->session->flashdata('pesan_berhasil')): ?>
      <div class="pb-alert pb-alert--success">
        <?= $this->session->flashdata('pesan_berhasil'); ?>
      </div>
    <?php endif; ?>

    <div class="pb-grid">
      <div>
        <div class="pb-title">Menu</div>
        <div class="pb-subtitle">menu makanan</div>

        <div class="pb-list">
          <?php if(!empty($items)): ?>
            <?php foreach($items as $it): ?>
              <div class="pb-row">
                <div class="pb-row-qty"><?= (int)($it['qty'] ?? 1); ?>x</div>
                <div class="pb-row-name"><?= htmlspecialchars((string)($it['nama'] ?? 'Item')); ?></div>
              </div>
            <?php endforeach; ?>
          <?php else: ?>
            <div style="opacity:.7;font-size:13px;">Belum ada item.</div>
          <?php endif; ?>
        </div>

        <div class="pb-total">
          <div class="pb-total-label">TOTAL :</div>
          <div>Rp <?= number_format((int)($total ?? 0), 0, ',', '.'); ?></div>
        </div>
      </div>

      <div class="pb-divider"></div>

      <div>
        <div class="pb-title">Pembayaran</div>

        <form method="post" action="<?= site_url('member/pembayaran/submit/'.(int)$id_pesanan); ?>">

          <div class="pb-pay-group">
            <div class="pb-pay-label">Qris</div>

            <label class="pb-pay-option">
              <input type="radio" name="metode" value="midtrans">
              <div class="pb-pay-box">Qris</div>
            </label>

            <div style="font-size:12px;opacity:.75;margin-top:8px;">
              Pembayaran otomatis terverifikasi.
            </div>

            <button type="button" id="btnMidtrans" class="pb-btn-mid" style="display:none;">
              BAYAR MIDTRANS
            </button>
          </div>

          <div class="pb-pay-group">
            <div class="pb-pay-label">Cash on delivery</div>

            <label class="pb-pay-option">
              <input type="radio" name="metode" value="cod" checked>
              <div class="pb-pay-box">COD</div>
            </label>
          </div>

          <div class="pb-bottom" id="pbCtaPesan">
            <button type="submit" class="pb-btn-pesan">PESAN</button>
          </div>

        </form>
      </div>
    </div>
  </section>
</main>

<?php if (!empty($mid_client_key)): ?>
<?php
$snapSrc = !empty($mid_production)
  ? 'https://app.midtrans.com/snap/snap.js'
  : 'https://app.sandbox.midtrans.com/snap/snap.js';
?>
<script src="<?= $snapSrc; ?>" data-client-key="<?= html_escape($mid_client_key); ?>"></script>

<script>
(function () {
  const radios   = document.querySelectorAll('input[name="metode"]');
  const btnMid   = document.getElementById('btnMidtrans');
  const btnPesan = document.getElementById('pbCtaPesan');

  function refreshUI() {
    const pick = document.querySelector('input[name="metode"]:checked');
    if (!pick) return;

    if (pick.value === 'midtrans') {
      btnMid.style.display = 'inline-flex';
      btnPesan.style.display = 'none';
    } else {
      btnMid.style.display = 'none';
      btnPesan.style.display = '';
    }
  }

  radios.forEach(r => r.addEventListener('change', refreshUI));
  refreshUI();

  function finalize(orderId) {
    const url = "<?= site_url('member/pembayaran/finalize_midtrans/'.(int)$id_pesanan); ?>" +
                "?order_id=" + encodeURIComponent(orderId);
    window.location.href = url;
  }

  btnMid.addEventListener('click', async () => {
    btnMid.disabled = true;

    try {
      const res = await fetch(
        "<?= site_url('member/pembayaran/snap_token/'.(int)$id_pesanan); ?>",
        { headers: { 'Accept': 'application/json' }, credentials: 'same-origin' }
      );

      const ct = (res.headers.get('content-type') || '').toLowerCase();
      if (!ct.includes('application/json')) {
        const txt = await res.text();
        console.log('snap_token NON-JSON response (potongan):', txt.slice(0, 300));
        alert('snap_token tidak mengembalikan JSON (kemungkinan redirect/login/error HTML).');
        return;
      }

      const json = await res.json();
      if (!json.ok) {
        alert(json.msg || 'Gagal membuat token');
        return;
      }

      snap.pay(json.token, {
        onSuccess: () => finalize(json.order_id),
        onPending: () => finalize(json.order_id),
        onError: () => alert('Pembayaran dibatalkan')
      });

    } catch (e) {
      alert(e.message);
    } finally {
      btnMid.disabled = false;
    }
  });
})();
</script>
<?php endif; ?>
