<?php
  $st = strtolower(trim((string)($status ?? '')));
  $st = str_replace([' ', '-'], '_', $st);
  if ($st === 'siap_diambil') $st = 'siap_ambil';

  $step1 = ($st === 'diproses' || $st === 'siap_ambil' || $st === 'selesai');
  $step2 = ($st === 'siap_ambil' || $st === 'selesai');
  $step3 = ($st === 'selesai');

  function trk_panel_img($foto){
    $foto = trim((string)$foto);
    if ($foto === '') return base_url('assets/img/placeholder.jpg');
    if (preg_match('~^https?://~i', $foto)) return $foto;
    return base_url($foto);
  }
?>

<div class="rm-notif-panel-content">
  <main class="trk-main">
    <div class="trk-wrap">

      <div class="trk-head">
        <img class="trk-brand-logo" src="<?= base_url('assets/img/logodarasulung.jpeg'); ?>" alt="Dara Sulung">
        <div class="trk-brand">RUMAH MAKAN DARA SULUNG</div>
      </div>

      <?php if (!empty($pesan_kosong)): ?>
        <div class="trk-empty trk-empty-box"><?= htmlspecialchars($pesan_kosong); ?></div>
      <?php else: ?>
        <div class="trk-progress">
          <div class="trk-step <?= $step1?'active':''; ?>">
            <div class="trk-ico"><i class="bi bi-arrow-repeat"></i></div>
            <div class="trk-label">Diproses</div>
          </div>

          <div class="trk-line <?= $step2?'active':''; ?>"></div>

          <div class="trk-step <?= $step2?'active':''; ?>">
            <div class="trk-ico"><i class="bi bi-box-seam"></i></div>
            <div class="trk-label">Siap diambil</div>
          </div>

          <div class="trk-line <?= $step3?'active':''; ?>"></div>

          <div class="trk-step <?= $step3?'active':''; ?>">
            <div class="trk-ico"><i class="bi bi-check2"></i></div>
            <div class="trk-label">Selesai</div>
          </div>
        </div>

        <!-- Timeline -->
        <div class="trk-card">
          <table class="trk-table">
            <thead>
              <tr>
                <th>Waktu</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              <?php if (empty($timeline)): ?>
                <tr>
                  <td>-</td>
                  <td>Status belum tercatat.</td>
                </tr>
              <?php else: ?>
                <?php foreach ($timeline as $t): ?>
                  <?php
                    $w = (string)($t['waktu'] ?? '');
                    $label = (string)($t['status_label'] ?? ($t['status'] ?? ''));
                    $jam = $w;
                    if ($w !== '' && preg_match('/\b(\d{2}):(\d{2})\b/', $w, $m)) {
                      $jam = $m[1].'.'.$m[2];
                    }
                  ?>
                  <tr>
                    <td><?= htmlspecialchars($jam); ?></td>
                    <td>Pesanan "<?= htmlspecialchars($label); ?>"</td>
                  </tr>
                <?php endforeach; ?>
              <?php endif; ?>
            </tbody>
          </table>
        </div>

        <!-- Items -->
        <div class="trk-items">
          <?php if (empty($items)): ?>
            <div class="trk-empty">Item pesanan tidak ditemukan.</div>
          <?php else: ?>
            <?php foreach ($items as $it): ?>
              <?php
                $nama = (string)($it['nama'] ?? 'Item');
                $qty  = (int)($it['qty'] ?? 1);
                $img  = trk_panel_img($it['foto'] ?? '');
              ?>
              <div class="trk-item">
                <img class="trk-item-img" src="<?= $img; ?>" alt="<?= htmlspecialchars($nama); ?>">
                <div class="trk-item-name"><?= htmlspecialchars($nama); ?> <?= (int)$qty; ?>x</div>
              </div>
            <?php endforeach; ?>
          <?php endif; ?>
        </div>

        <!-- Actions -->
        <div class="trk-actions">
          <div class="trk-done <?= $step3?'is-done':''; ?>">
            <i class="bi bi-check2"></i>
            <span>PESANAN SELESAI</span>
          </div>

          <button type="button" class="trk-ok" data-rm-notif-close>oke</button>
        </div>

      <?php endif; ?>

    </div>
  </main>
</div>
