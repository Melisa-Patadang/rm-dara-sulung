<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Forgot Password</title>
  <link rel="stylesheet" href="<?= base_url('assets/member/member.css'); ?>">
</head>
<body class="mb-body">

  <div class="mb-yellow">
    <div class="mb-card mb-card--login">

      <div class="mb-head">FORGOT PASSWORD</div>

      <?php if ($this->session->flashdata('member_error')): ?>
        <div class="mb-alert mb-alert--danger"><?= $this->session->flashdata('member_error'); ?></div>
      <?php endif; ?>

      <?php if ($this->session->flashdata('member_success')): ?>
        <div class="mb-alert mb-alert--success"><?= $this->session->flashdata('member_success'); ?></div>
      <?php endif; ?>

      <!-- STEP 1 -->
      <form class="mb-form" method="post" action="<?= site_url('forgot'); ?>" autocomplete="off">
        <input type="hidden" name="step" value="request_otp">

        <label class="mb-label">Email</label>
        <input class="mb-input" type="email" name="email" placeholder="isi email terdaftar" required>

        <button class="mb-btn" type="submit">Kirim OTP</button>
      </form>

      <hr style="border:0;border-top:1px solid #eee;margin:22px 0;">

      <!-- STEP 2 -->
      <form class="mb-form" method="post" action="<?= site_url('forgot'); ?>" autocomplete="off">
        <input type="hidden" name="step" value="reset_password">

        <label class="mb-label">OTP</label>
        <input class="mb-input" type="text" name="otp" placeholder="6 digit OTP" maxlength="6" required>

        <label class="mb-label">Password Baru</label>
        <input class="mb-input" type="password" name="password" placeholder="isi password baru" required>

        <label class="mb-label">Konfirmasi Password</label>
        <input class="mb-input" type="password" name="password2" placeholder="ulangi password" required>

        <button class="mb-btn" type="submit">Reset Password</button>

        <div class="mb-foot">
          back to <a href="<?= site_url('login'); ?>">login</a>
        </div>
      </form>

    </div>
  </div>

</body>
</html>
