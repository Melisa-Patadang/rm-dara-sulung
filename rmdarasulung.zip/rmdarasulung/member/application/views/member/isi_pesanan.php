<main class="ip-main">
    <div class="ip-wrap">
  <div class="ip-topbar">
    <a class="ip-back" href="<?= site_url('member/menu'); ?>">&lt; Back</a>
  </div>

  <section class="ip-card">

    <h2 class="ip-title">PEMESANAN</h2>

    <div class="ip-summary">
      <div class="ip-summary-cell">
        <div class="ip-summary-label">Makanan</div>
        <div class="ip-summary-value"><?= (int)($count_makanan ?? 0); ?></div>
      </div>

      <div class="ip-summary-cell">
        <div class="ip-summary-label">Minuman</div>
        <div class="ip-summary-value"><?= (int)($count_minuman ?? 0); ?></div>
      </div>

      <div class="ip-summary-cell">
        <div class="ip-summary-label">Cemilan</div>
        <div class="ip-summary-value"><?= (int)($count_cemilan ?? 0); ?></div>
      </div>
    </div>

    <h2 class="ip-title ip-title-spaced">ISI DATA</h2>

    <form class="ip-form" method="post" action="<?= site_url('member/isi_pesanan/submit'); ?>">
      <div class="ip-grid">
        <div class="ip-field">
          <label class="ip-label" for="nama">Nama</label>
          <input class="ip-input" id="nama" name="nama" type="text" placeholder="isi nama"
                 value="<?= htmlspecialchars($prefill_nama ?? ''); ?>" required>
        </div>

        <div class="ip-field">
          <label class="ip-label" for="alamat">Alamat</label>
          <input class="ip-input" id="alamat" name="alamat" type="text" placeholder="isi alamat"
                 value="<?= htmlspecialchars($prefill_alamat ?? ''); ?>" required>
        </div>

        <div class="ip-field">
          <label class="ip-label" for="wa">Nomor wa</label>
          <input class="ip-input" id="wa" name="no_wa" type="tel" placeholder="isi nomor wa"
                 value="<?= htmlspecialchars($prefill_wa ?? ''); ?>" required>
        </div>

        <div class="ip-field ip-field-empty"></div>
      </div>

      <div class="ip-cta">
        <button class="ip-btn" type="submit">PESAN</button>
      </div>
    </form>

  </section>
  </div>
</main>
