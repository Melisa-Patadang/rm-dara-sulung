<footer class="rm-footer">
  <div class="rm-wrap">
    <div class="rm-footer-grid">

      <div class="rm-footer-brand">
        RUMAH<br>MAKAN<br>DARA<br>SULUNG
      </div>

      <div>
        <div class="rm-footer-title">Help</div>
        <div class="rm-footer-item">Contact us</div>
        <div class="rm-footer-item">FAQ</div>
        <div class="rm-footer-item">payment</div>
      </div>

      <div>
        <div class="rm-footer-title">Follow Us</div>
        <div class="rm-footer-item">Instagram</div>
        <div class="rm-footer-item">Facebook</div>
        <div class="rm-footer-item">Whatsapp</div>
      </div>

    </div>
  </div>
</footer>

</body>
</html>
