<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Rumah Makan Dara Sulung</title>

  <!-- Bootstrap Icons (CDN) -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

  <!-- CSS -->
  <link rel="stylesheet" href="<?= base_url('assets/css/member-dashboard.css'); ?>">
  <!-- tracking_pesanan.css tidak wajib untuk panel notif karena panel sudah membawa style sendiri -->
</head>
<body>

<header class="rm-topnav">
  <div class="rm-wrap">
    <div class="rm-topnav-inner">

      <!-- LEFT: Logo + Brand -->
      <div class="rm-brand">
        <img
          class="rm-logo"
          src="<?= base_url('assets/img/logodarasulung.jpeg'); ?>"
          alt="Logo Dara Sulung"
        >
        <div class="rm-brand-text">RUMAH MAKAN DARA SULUNG</div>
      </div>

      <!-- RIGHT: Icons + user + logout -->
      <div class="rm-nav-right">
        <!-- notif langsung ke tracking -->
        <a class="rm-icon-btn" href="#" id="rmNotifBtn" title="Notifikasi" aria-label="Notifikasi">
          <i class="bi bi-bell-fill"></i>
          <span id="rmNotifBadge">0</span>
        </a>

        <a class="rm-icon-btn" href="#" title="Keranjang" aria-label="Keranjang">
          <i class="bi bi-cart-fill"></i>
        </a>

        <div class="rm-user"><?= htmlspecialchars($nama ?: 'VELO'); ?></div>
        <a class="rm-logout" href="<?= site_url('member/login/logout'); ?>">Logout</a>
      </div>

    </div>
  </div>
</header>

<!-- NOTIF POPUP (modal) -->
<div class="rm-notif-overlay" id="rmNotifOverlay" aria-hidden="true"></div>
<div class="rm-notif-modal" id="rmNotifModal" aria-hidden="true">
  <div class="rm-notif-box" role="dialog" aria-modal="true" aria-label="Notifikasi">
    
    <div class="rm-notif-body" id="rmNotifBody">
      <div class="rm-notif-loading">Memuat notifikasi...</div>
    </div>
  </div>
</div>

<script>
(function(){
  var badge = document.getElementById('rmNotifBadge');
  var btn   = document.getElementById('rmNotifBtn');
  var ov    = document.getElementById('rmNotifOverlay');
  var dr    = document.getElementById('rmNotifModal');
  var body  = document.getElementById('rmNotifBody');
  var xbtn  = document.getElementById('rmNotifClose');

  function setBadge(c){
    if(!badge) return;
    c = parseInt(c || 0, 10);
    if(!isFinite(c) || c <= 0){ badge.style.display = 'none'; return; }
    badge.textContent = String(c);
    badge.style.display = 'inline-block';
  }

  function refreshBadge(){
    fetch("<?= site_url('member/notifikasi/count_json'); ?>", { credentials: 'same-origin' })
      .then(function(r){ return r.json(); })
      .then(function(j){ setBadge(j && j.count ? j.count : 0); })
      .catch(function(){ /* silent */ });
  }

  function closeDrawer(){
    if(!dr || !ov) return;
    dr.classList.remove('open');
    ov.classList.remove('open');
    dr.setAttribute('aria-hidden','true');
    ov.setAttribute('aria-hidden','true');
    refreshBadge();
  }

  function openDrawer(){
    if(!dr || !ov || !body) return;
    dr.classList.add('open');
    ov.classList.add('open');
    dr.setAttribute('aria-hidden','false');
    ov.setAttribute('aria-hidden','false');

    body.innerHTML = '<div class="rm-notif-loading">Memuat notifikasi...</div>';

    fetch("<?= site_url('member/notifikasi/panel_html'); ?>", { credentials: 'same-origin' })
      .then(function(r){
        if(!r.ok) throw new Error('HTTP ' + r.status);
        return r.text();
      })
      .then(function(html){
        body.innerHTML = html;
        // tombol-tombol close di dalam konten
        var closes = body.querySelectorAll('[data-rm-notif-close]');
        closes.forEach(function(el){
          el.addEventListener('click', function(e){ e.preventDefault(); closeDrawer(); });
        });
      })
      .catch(function(){
        body.innerHTML = '<div class="rm-notif-loading">Notifikasi tidak bisa dimuat. Pastikan kamu sudah login dan punya pesanan.</div>';
      });
  }

  // initial badge
  refreshBadge();

  if(btn){
    btn.addEventListener('click', function(e){
      e.preventDefault();
      openDrawer();
    });
  }
  if(ov){ ov.addEventListener('click', closeDrawer); }
  // klik area kosong modal (bukan box) menutup
  if(dr){
    dr.addEventListener('click', function(e){
      if(e.target === dr) closeDrawer();
    });
  }
  if(xbtn){ xbtn.addEventListener('click', closeDrawer); }
  document.addEventListener('keydown', function(e){
    if(e.key === 'Escape') closeDrawer();
  });
})();
</script>
