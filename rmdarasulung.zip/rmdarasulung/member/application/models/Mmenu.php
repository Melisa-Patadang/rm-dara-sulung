<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mmenu extends CI_Model
{
    private $table = 'menu';
    public function getPaginated()
    {
        $this->load->library('pagination');

        $total = $this->db->count_all($this->table);

        $config['base_url'] = base_url('member/menu/index');
        $config['total_rows'] = $total;
        $config['per_page'] = 11;
        $config['uri_segment'] = 4;

        $this->pagination->initialize($config);

        $start = $this->uri->segment(4, 0);

        $data['menu'] = $this->db
            ->limit($config['per_page'], $start)
            ->get($this->table)
            ->result_array();
        foreach ($data['menu'] as &$r) {
            $r = $this->normalize_row($r);
        }
        unset($r);

        $data['pagination'] = $this->pagination->create_links();
        $data['start'] = $start;

        return $data;
    }

    public function getPaginatedFiltered(string $kategori, string $q = '')
{
    $this->load->library('pagination');

 
    $f = $this->normalize_filter($kategori, $q);
    $kategori = $f['kategori'];
    $q        = $f['q'];

    $total = $this->count_by_kategori($kategori, $q);

    $config = [];
    $config['base_url']     = base_url('member/menu/index');
    $config['total_rows']   = $total;
    $config['per_page']     = 11;
    $config['uri_segment']  = 4;

    $qs = [];
    $qs['kategori'] = $kategori;
    if ($q !== '') $qs['q'] = $q;

    $suffix = '?' . http_build_query($qs);
    $config['suffix']    = $suffix; 
    $config['first_url'] = $config['base_url'] . '/0' . $suffix; 

    $config['reuse_query_string'] = true;

    $this->pagination->initialize($config);

    $start = (int)$this->uri->segment(4, 0);

    $this->db->from($this->table);
    $this->db->where('kategori', $kategori);

    if ($q !== '') {
        $this->db->group_start();
        $this->db->like('nama_menu', $q);
        $this->db->group_end();
    }

    $this->db->order_by('id_menu', 'DESC');
    $rows = $this->db->limit($config['per_page'], $start)->get()->result_array();

    foreach ($rows as &$r) {
        $r = $this->normalize_row($r);
    }
    unset($r);

    return [
        'menu'       => $rows,
        'pagination' => (string)$this->pagination->create_links(),
        'start'      => $start,
        'kategori'   => $kategori,
        'q'          => $q,
    ];
}

    public function normalize_filter(string $kategori, string $q): array
    {
        $kategori = strtolower(trim($kategori));
        $q        = trim($q);

        if (!in_array($kategori, ['makanan', 'minuman', 'cemilan'], true)) {
            $kategori = 'makanan';
        }

        return [
            'kategori' => $kategori,
            'q'        => $q,
        ];
    }

    public function split_items(array $items, int $left_count = 7): array
    {
        $left_count = max(0, (int)$left_count);

        return [
            'left_items'  => array_slice($items, 0, $left_count),
            'right_items' => array_slice($items, $left_count),
        ];
    }

    public function count_by_kategori(string $kategori, string $q = ''): int
    {
        if (!$this->db->table_exists($this->table)) return 0;

        $this->db->from($this->table);
        $this->db->where('kategori', $kategori);

        if ($q !== '') {
            $this->db->group_start();
            $this->db->like('nama_menu', $q);
            $this->db->group_end();
        }

        return (int)$this->db->count_all_results();
    }

    public function get_by_kategori(string $kategori, string $q = ''): array
    {
        if (!$this->db->table_exists($this->table)) return [];

        $this->db->from($this->table);
        $this->db->where('kategori', $kategori);

        if ($q !== '') {
            $this->db->group_start();
            $this->db->like('nama_menu', $q);
            $this->db->group_end();
        }

        $this->db->order_by('id_menu', 'DESC');

        $rows = $this->db->get()->result_array();

        foreach ($rows as &$r) {
            $r = $this->normalize_row($r);
        }
        unset($r);

        return $rows;
    }

    public function get_by_id(int $id_menu): ?array
    {
        if ($id_menu <= 0) return null;
        if (!$this->db->table_exists($this->table)) return null;

        $row = $this->db->get_where($this->table, ['id_menu' => $id_menu])->row_array();
        if (!$row) return null;

        return $this->normalize_row($row);
    }

    private function normalize_row(array $row): array
    {
        $id   = (int)($row['id_menu'] ?? 0);
        $nama = (string)($row['nama_menu'] ?? '');
        $desk = (string)($row['deskripsi'] ?? '');
        $hrg  = (int)($row['harga'] ?? 0);
        $kat  = (string)($row['kategori'] ?? '');

        $src = trim((string)($row['gambar'] ?? ($row['foto'] ?? '')));

        if ($src === '') {
            $foto = 'assets/img/placeholder.jpg';
        } elseif (preg_match('~^https?://~i', $src)) {
            $foto = $src;
        } elseif (strpos($src, '/') !== false) {
            $foto = $src;
        } else {
            $foto = '../admin/uploads/menu/' . $src;
        }

        $row['id_menu']   = $id;
        $row['nama_menu'] = $nama;
        $row['deskripsi'] = $desk;
        $row['harga']     = $hrg;
        $row['kategori']  = $kat;
        $row['foto']      = $foto;

        return $row;
    }
}
