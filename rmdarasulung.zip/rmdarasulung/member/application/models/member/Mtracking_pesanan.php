<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mtracking_pesanan extends CI_Model
{
    private string $t_pesanan = 'pesanan';

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    private function has_field(string $table, string $field): bool
    {
        return $this->db->field_exists($field, $table);
    }

    private function first_field(string $table, array $candidates): string
    {
        foreach ($candidates as $f) {
            if ($this->has_field($table, $f)) return $f;
        }
        return '';
    }

   private function where_pemilik(int $member_id): void
{
    $cols = [];
    foreach (['member_id','id_member','id_user','user_id','id_pelanggan','pelanggan_id'] as $c) {
        if ($this->has_field($this->t_pesanan, $c)) $cols[] = $c;
    }
    if (empty($cols)) return;

    $this->db->group_start();
    $first = true;
    foreach ($cols as $c) {
        if ($first) { $this->db->where($c, $member_id); $first = false; }
        else        { $this->db->or_where($c, $member_id); }
    }
    $this->db->group_end();
}

    public function resolve_pesanan_id(int $id_user, $id_pesanan = null): int
    {
        $idcol = $this->first_field($this->t_pesanan, ['id_pesanan','pesanan_id']);
        if ($idcol === '') return 0;

        if ($id_pesanan !== null && $id_pesanan !== '') {
            $id = (int)$id_pesanan;
            $this->db->from($this->t_pesanan);
            $this->db->where($idcol, $id);
            $this->where_pemilik($id_user);
            $q = $this->db->get();
            return ($q && $q->num_rows() > 0) ? $id : 0;
        }

        $status_col  = $this->first_field($this->t_pesanan, ['status_pesanan','status']);
        $created_col = $this->first_field($this->t_pesanan, ['tanggal_pesanan','created_at','tgl_pesanan','tanggal']);

        $this->db->select($idcol.' AS id_pesanan');
        $this->db->from($this->t_pesanan);
        $this->where_pemilik($id_user);

        if ($status_col !== '') $this->db->where($status_col.' !=', 'selesai');
        if ($created_col !== '') $this->db->order_by($created_col, 'DESC');
        $this->db->order_by($idcol, 'DESC');

        $q = $this->db->get();
        if ($q && $q->num_rows() > 0) return (int)$q->row()->id_pesanan;

        $this->db->select($idcol.' AS id_pesanan');
        $this->db->from($this->t_pesanan);
        $this->where_pemilik($id_user);
        if ($created_col !== '') $this->db->order_by($created_col, 'DESC');
        $this->db->order_by($idcol, 'DESC');

        $q2 = $this->db->get();
        return ($q2 && $q2->num_rows() > 0) ? (int)$q2->row()->id_pesanan : 0;
    }

    public function get_status(int $id_pesanan): string
    {
        $idcol     = $this->first_field($this->t_pesanan, ['id_pesanan','pesanan_id']);
        $statuscol = $this->first_field($this->t_pesanan, ['status_pesanan','status']);
        if ($idcol === '' || $statuscol === '') return '';

        $this->db->select($statuscol.' AS st');
        $this->db->from($this->t_pesanan);
        $this->db->where($idcol, $id_pesanan);
        $q = $this->db->get();

        return ($q && $q->num_rows() > 0) ? (string)$q->row()->st : '';
    }

    public function get_timeline(int $id_pesanan): array
    {
        if ($this->db->table_exists('status_pesanan')) {
            $t     = 'status_pesanan';
            $idcol = $this->first_field($t, ['id_pesanan','pesanan_id']);
            $wcol  = $this->first_field($t, ['waktu','created_at','tanggal','tanggal_status']);
            $scol  = $this->first_field($t, ['status_label','status','keterangan']);

            if ($idcol !== '') {
                $sel_w = ($wcol !== '' ? $wcol : "''")." AS waktu";
                $sel_s = ($scol !== '' ? $scol : "''")." AS status_label";

                $this->db->select($sel_w.', '.$sel_s);
                $this->db->from($t);
                $this->db->where($idcol, $id_pesanan);
                if ($wcol !== '') $this->db->order_by($wcol, 'ASC');
                $q = $this->db->get();

                $rows = $q ? $q->result_array() : [];
                if (!empty($rows)) return $rows;
            }
        }

        $st = $this->get_status($id_pesanan);
        return $st === '' ? [] : [[ 'waktu' => '', 'status_label' => $st ]];
    }

    public function get_items(int $id_pesanan): array
    {
        $t = $this->db->table_exists('detail_pesanan') ? 'detail_pesanan'
           : ($this->db->table_exists('pesanan_detail') ? 'pesanan_detail' : '');

        if ($t === '') return [];

        $idcol = $this->first_field($t, ['id_pesanan','pesanan_id']);
        if ($idcol === '') return [];

        $nama = $this->first_field($t, ['nama_menu','nama','menu']);
        $qty  = $this->first_field($t, ['qty','jumlah']);
        $foto = $this->first_field($t, ['foto','gambar','image']);

        $this->db->select(
            ($nama !== '' ? $nama : "''")." AS nama, ".
            ($qty  !== '' ? $qty  : "1")." AS qty, ".
            ($foto !== '' ? $foto : "''")." AS foto"
        );
        $this->db->from($t);
        $this->db->where($idcol, $id_pesanan);

        $q = $this->db->get();
        return $q ? $q->result_array() : [];
    }

    private function normalize_status(string $s): string
    {
        $s = strtolower(trim($s));
        $s = str_replace([' ', '-'], '_', $s);
        if ($s === 'siap_diambil') $s = 'siap_ambil';
        if ($s === 'siap') $s = 'siap_ambil';
        return $s;
    }

    private function latest_status_map(array $ids): array
    {
        $ids = array_values(array_filter(array_map('intval', $ids), fn($v) => $v > 0));
        if (empty($ids)) return [];
        if (!$this->db->table_exists('status_pesanan')) return [];

        $t = 'status_pesanan';
        $idcol = $this->first_field($t, ['id_status']);
        $pidcol = $this->first_field($t, ['id_pesanan','pesanan_id']);
        $wcol  = $this->first_field($t, ['waktu_update','waktu','created_at','tanggal','tanggal_status']);
        $scol  = $this->first_field($t, ['status','status_label','keterangan']);
        if ($pidcol === '' || $scol === '') return [];

        $this->db->from($t);
        $this->db->where_in($pidcol, $ids);
        if ($idcol !== '') $this->db->order_by($idcol, 'DESC');
        elseif ($wcol !== '') $this->db->order_by($wcol, 'DESC');

        $rows = $this->db->get()->result_array();
        $out = [];
        foreach ($rows as $r) {
            $pid = (int)($r[$pidcol] ?? 0);
            if ($pid <= 0) continue;
            if (isset($out[$pid])) continue; // sudah ambil yang paling baru

            $out[$pid] = [
                'status' => (string)($r[$scol] ?? ''),
                'waktu'  => (string)($wcol !== '' ? ($r[$wcol] ?? '') : ''),
            ];
        }
        return $out;
    }

    public function count_badge(int $member_id): int
    {
        if (!$this->db->table_exists($this->t_pesanan)) return 0;

        $idcol = $this->first_field($this->t_pesanan, ['id_pesanan','pesanan_id']);
        if ($idcol === '') return 0;

        $status_col = $this->first_field($this->t_pesanan, ['status_pesanan','status']);

        $this->db->select($idcol.' AS id_pesanan');
        if ($status_col !== '') $this->db->select($status_col.' AS st');
        $this->db->from($this->t_pesanan);
        $this->where_pemilik($member_id);
        $this->db->order_by($idcol, 'DESC');
        $this->db->limit(500);

        $rows = $this->db->get()->result_array();
        if (empty($rows)) return 0;

        $ids = array_column($rows, 'id_pesanan');
        $last = $this->latest_status_map($ids);

        $count = 0;
        foreach ($rows as $r) {
            $pid = (int)($r['id_pesanan'] ?? 0);
            if ($pid <= 0) continue;

            $st = (string)($r['st'] ?? '');
            if ($st === '') $st = (string)($last[$pid]['status'] ?? '');

            $norm = $this->normalize_status($st);
            if ($norm === 'diproses' || $norm === 'siap_ambil') $count++;
        }

        return $count;
    }

}