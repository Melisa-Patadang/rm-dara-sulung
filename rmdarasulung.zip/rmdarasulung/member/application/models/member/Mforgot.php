<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mforgot extends CI_Model
{
    private string $table = 'user';

    public function __construct()
    {
        parent::__construct();
        $this->load->library(['session','email']);
    }

    public function request_otp(string $email): void
    {
        $user = $this->get_user_by_email($email);

        if ($user) {
            $otp = (string)random_int(100000, 999999);
            $exp = time() + 10 * 60; 

            $this->session->set_userdata('fp_email', $email);
            $this->session->set_userdata('fp_otp', password_hash($otp, PASSWORD_BCRYPT));
            $this->session->set_userdata('fp_exp', $exp);

            $this->send_otp_email($email, $otp);
        }

        $this->session->set_flashdata('member_success', 'Jika email terdaftar, kode OTP sudah dikirim.');
    }

    public function reset_with_otp(string $otp, string $new_password): bool
    {
        $email = (string)$this->session->userdata('fp_email');
        $hash  = (string)$this->session->userdata('fp_otp');
        $exp   = (int)$this->session->userdata('fp_exp');

        if (!$email || !$hash || !$exp) {
            $this->session->set_flashdata('member_error', 'Silakan minta OTP terlebih dahulu.');
            return false;
        }

        if (time() > $exp) {
            $this->clear_fp_session();
            $this->session->set_flashdata('member_error', 'OTP kedaluwarsa. Minta OTP lagi.');
            return false;
        }

        if (!password_verify($otp, $hash)) {
            $this->session->set_flashdata('member_error', 'OTP salah.');
            return false;
        }

        $user = $this->get_user_by_email($email);
        if (!$user) {
            $this->clear_fp_session();
            $this->session->set_flashdata('member_error', 'Akun tidak ditemukan.');
            return false;
        }

        $ok = $this->update_password((int)$user->id_user, password_hash($new_password, PASSWORD_BCRYPT));

        if ($ok) {
            $this->clear_fp_session();
            $this->session->set_flashdata('member_success', 'Password berhasil diubah. Silakan login.');
            return true;
        }

        $this->session->set_flashdata('member_error', 'Gagal update password.');
        return false;
    }

    private function get_user_by_email(string $email)
    {
        return $this->db->get_where($this->table, ['email' => $email])->row();
    }

    private function update_password(int $id_user, string $password_hash): bool
    {
        return (bool)$this->db->where('id_user', $id_user)->update($this->table, [
            'password' => $password_hash
        ]);
    }

    private function clear_fp_session(): void
    {
        $this->session->unset_userdata(['fp_email','fp_otp','fp_exp']);
    }

    private function send_otp_email(string $to, string $otp): void
    {
       
        $subject = 'Kode Reset Password - Dara Sulung';
        $message = "Kode OTP reset password Anda: {$otp}\nBerlaku 10 menit.\n\nJika Anda tidak meminta reset, abaikan.";

        $this->email->from('no-reply@darasulung.local', 'Dara Sulung');
        $this->email->to($to);
        $this->email->subject($subject);
        $this->email->message($message);

       
        @$this->email->send();
    }
}
