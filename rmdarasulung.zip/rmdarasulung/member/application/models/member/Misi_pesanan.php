<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Misi_pesanan extends CI_Model
{
    private $t_menu           = 'menu';
    private $t_pesanan        = 'pesanan';
    private $t_pesanan_detail = 'pesanan_detail';

    public function __construct()
    {
        parent::__construct();
        $this->load->library('session');
        $this->load->database();

        // Pakai tabel detail yang benar (admin pakai: detail_pesanan)
        if ($this->db->table_exists('detail_pesanan')) {
            $this->t_pesanan_detail = 'detail_pesanan';
        }
    }

    private function cart_raw(): array
    {
        $cart = $this->session->userdata('member_cart');
        return is_array($cart) ? $cart : [];
    }

    public function cart_has_items(): bool
    {
        $cart = $this->cart_raw();
        return !empty($cart);
    }

    public function get_summary_kategori(int $member_id): array
    {
        $out = ['makanan' => 0, 'minuman' => 0, 'cemilan' => 0];

        $cart = $this->cart_raw();
        if (empty($cart)) return $out;

        $ids = [];
        foreach ($cart as $row) {
            $id = (int)($row['id_menu'] ?? 0);
            if ($id > 0) $ids[] = $id;
        }
        $ids = array_values(array_unique($ids));
        if (empty($ids)) return $out;

        $mapKat = [];
        if ($this->db->table_exists($this->t_menu)) {
            $rows = $this->db->select('id_menu, kategori')
                ->from($this->t_menu)
                ->where_in('id_menu', $ids)
                ->get()->result_array();

            foreach ($rows as $r) {
                $mapKat[(int)$r['id_menu']] = strtolower(trim((string)$r['kategori']));
            }
        }

        foreach ($cart as $row) {
            $id  = (int)($row['id_menu'] ?? 0);
            $qty = (int)($row['qty'] ?? 0);
            if ($qty <= 0) continue;

            $kat = (string)($mapKat[$id] ?? '');
            if (isset($out[$kat])) $out[$kat] += $qty;
        }

        return $out;
    }

    public function checkout(int $member_id, array $input): array
    {
        $cart = $this->cart_raw();
        if (empty($cart)) return ['ok' => false, 'msg' => 'Keranjang kosong.'];

        if (!$this->db->table_exists($this->t_pesanan)) {
            return ['ok' => false, 'msg' => 'Tabel pesanan tidak ditemukan.'];
        }

        $ids = [];
        foreach ($cart as $row) {
            $id = (int)($row['id_menu'] ?? 0);
            if ($id > 0) $ids[] = $id;
        }
        $ids = array_values(array_unique($ids));

        $mapKat = [];
        if (!empty($ids) && $this->db->table_exists($this->t_menu)) {
            $rows = $this->db->select('id_menu, kategori')
                ->from($this->t_menu)
                ->where_in('id_menu', $ids)
                ->get()->result_array();
            foreach ($rows as $r) {
                $mapKat[(int)$r['id_menu']] = strtolower(trim((string)$r['kategori']));
            }
        }

        $total_qty = 0;
        $total_amount = 0;
        foreach ($cart as $row) {
            $qty   = (int)($row['qty'] ?? 0);
            $harga = (int)($row['harga'] ?? 0);
            $total_qty += $qty;
            $total_amount += ($qty * $harga);
        }

        $this->db->trans_begin();

        try {
            $id_pelanggan = $this->insert_pelanggan($input);
            if ($id_pelanggan > 0) {
                $this->session->set_userdata('member_pelanggan_id', $id_pelanggan);
            }

            $header = [
                'member_id'   => $member_id,
                'id_member'   => $member_id,
                'user_id'     => $member_id,
                'id_user'     => $member_id,

                'id_pelanggan'=> $id_pelanggan,
                'pelanggan_id'=> $id_pelanggan,

                'nama'        => $input['nama'] ?? null,
                'alamat'      => $input['alamat'] ?? null,
                'no_wa'       => $input['no_wa'] ?? null,

                'tanggal'     => date('Y-m-d H:i:s'),
                'status'      => 'baru',
                'total_qty'   => $total_qty,
                'total_amount'=> $total_amount,
                'total_harga' => $total_amount,
            ];

            $header = $this->filter_insert_by_table($this->t_pesanan, $header);
            $this->db->insert($this->t_pesanan, $header);

            $id_pesanan = (int)$this->db->insert_id();
            if ($id_pesanan <= 0) {
                $this->db->trans_rollback();
                return ['ok' => false, 'msg' => 'Gagal membuat pesanan.'];
            }

        
            if ($this->db->table_exists($this->t_pesanan_detail)) {
                foreach ($cart as $row) {
                    $id_menu = (int)($row['id_menu'] ?? 0);
                    $qty     = (int)($row['qty'] ?? 0);
                    $harga   = (int)($row['harga'] ?? 0);
                    if ($qty <= 0) continue;

                    $detail = [
                        'pesanan_id' => $id_pesanan,
                        'id_pesanan' => $id_pesanan,

                        'id_menu'    => $id_menu,
                        'menu_id'    => $id_menu,
                        'produk_id'  => $id_menu,

                        'nama_item'  => (string)($row['nama'] ?? ''),
                        'nama_menu'  => (string)($row['nama'] ?? ''),

                        'kategori'   => (string)($mapKat[$id_menu] ?? ''),

                        'qty'        => $qty,
                        'jumlah'     => $qty,

                        'harga'      => $harga,
                        'subtotal'   => $qty * $harga,
                        'total'      => $qty * $harga,
                    ];

                    $detail = $this->filter_insert_by_table($this->t_pesanan_detail, $detail);
                    $this->db->insert($this->t_pesanan_detail, $detail);
                }
            }

            if ($this->db->trans_status() === false) {
                $this->db->trans_rollback();
                return ['ok' => false, 'msg' => 'Transaksi database gagal.'];
            }

            $this->db->trans_commit();

            $this->session->unset_userdata('member_cart');

            return ['ok' => true, 'id_pesanan' => $id_pesanan];

        } catch (Throwable $e) {
            $this->db->trans_rollback();
            return ['ok' => false, 'msg' => 'Error: '.$e->getMessage()];
        }
    }

    private function filter_insert_by_table(string $table, array $data): array
    {
        if (!$this->db->table_exists($table)) return [];
        $fields  = $this->db->list_fields($table);
        $allowed = array_flip($fields);

        $out = [];
        foreach ($data as $k => $v) {
            if (isset($allowed[$k])) $out[$k] = $v;
        }
        return $out;
    }

    private function insert_pelanggan(array $input): int
    {
        if (!$this->db->table_exists('pelanggan')) return 0;

        $nama   = trim((string)($input['nama'] ?? ''));
        $alamat = trim((string)($input['alamat'] ?? ''));
        $no_hp  = trim((string)($input['no_wa'] ?? ''));

        if ($no_hp === '') return 0;

        $no_hp = preg_replace('/[\s\.\-]+/', '', $no_hp);
        if (strpos($no_hp, '+62') === 0) $no_hp = '0' . substr($no_hp, 3);
        if (strpos($no_hp, '62') === 0)  $no_hp = '0' . substr($no_hp, 2);

        $existing = $this->db->get_where('pelanggan', ['no_hp' => $no_hp])->row_array();
        if ($existing) {
            $id = (int)$existing['id_pelanggan'];

            $upd = [];
            if ($nama !== '' && ($existing['nama_pelanggan'] ?? '') !== $nama) $upd['nama_pelanggan'] = $nama;
            if ($alamat !== '' && ($existing['alamat'] ?? '') !== $alamat)     $upd['alamat'] = $alamat;

            if (!empty($upd)) {
                $this->db->where('id_pelanggan', $id)->update('pelanggan', $upd);
            }

            return $id;
        }

        $this->db->insert('pelanggan', [
            'nama_pelanggan' => $nama,
            'no_hp'          => $no_hp,
            'alamat'         => $alamat,
        ]);

        return (int)$this->db->insert_id();
    }
}
