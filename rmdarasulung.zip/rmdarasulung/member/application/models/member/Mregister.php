<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mregister extends CI_Model
{
    private string $table = 'user';

    public function username_exists(string $username): bool
    {
        return $this->db->where('username', $username)->from($this->table)->count_all_results() > 0;
    }

    public function email_exists(string $email): bool
    {
        return $this->db->where('email', $email)->from($this->table)->count_all_results() > 0;
    }

    public function create_member(array $data): bool
    {
        return (bool)$this->db->insert($this->table, $data);
    }
}
