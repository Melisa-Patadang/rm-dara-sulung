<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mpembayaran extends CI_Model
{
    private string $t_pesanan        = 'pesanan';
    private string $t_pesanan_detail = 'pesanan_detail';
    private string $t_pembayaran     = 'tabel_pembayaran';
    private string $t_transaksi      = 'transaksi_penjualan';

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
        $this->load->library('session');

        // Pakai tabel detail yang benar (admin biasanya: detail_pesanan)
        if ($this->db->table_exists('detail_pesanan')) {
            $this->t_pesanan_detail = 'detail_pesanan';
        }
    }

  
    private function apply_where_id_pesanan(string $table, int $id_pesanan): void
    {
        $has_id_pesanan = $this->db->field_exists('id_pesanan', $table);
        $has_pesanan_id = $this->db->field_exists('pesanan_id', $table);

        $this->db->group_start();

        $added = false;
        if ($has_id_pesanan) {
            $this->db->where('id_pesanan', $id_pesanan);
            $added = true;
        }
        if ($has_pesanan_id) {
            if ($added) $this->db->or_where('pesanan_id', $id_pesanan);
            else        $this->db->where('pesanan_id', $id_pesanan);
        }

        $this->db->group_end();
    }

    private function member_owner_cols(string $table): array
    {
        $cols = [];
        foreach (['member_id', 'id_member', 'user_id', 'id_user'] as $c) {
            if ($this->db->field_exists($c, $table)) $cols[] = $c;
        }
        return $cols;
    }

    private function pelanggan_owner_cols(string $table): array
    {
        $cols = [];
        foreach (['id_pelanggan', 'pelanggan_id'] as $c) {
            if ($this->db->field_exists($c, $table)) $cols[] = $c;
        }
        return $cols;
    }

    private function pesanan_key_col(string $table): ?string
    {
        if ($this->db->field_exists('id_pesanan', $table)) return 'id_pesanan';
        if ($this->db->field_exists('pesanan_id', $table)) return 'pesanan_id';
        return null;
    }

    private function filter_by_table_fields(string $table, array $data): array
    {
        if (!$this->db->table_exists($table)) return [];
        $fields  = $this->db->list_fields($table);
        $allowed = array_flip($fields);

        $out = [];
        foreach ($data as $k => $v) {
            if (isset($allowed[$k])) $out[$k] = $v;
        }
        return $out;
    }



    private function set_pesanan_status(int $id_pesanan, string $status): void
    {
        if (!$this->db->table_exists($this->t_pesanan)) return;

        $payload = [];

        
        if ($this->db->field_exists('status_pesanan', $this->t_pesanan)) {
            $payload['status_pesanan'] = $status;
        }

       
        if ($this->db->field_exists('status', $this->t_pesanan)) {
            $payload['status'] = $status;
        }

      
        if ($this->db->field_exists('tanggal_pesan', $this->t_pesanan)) {
            $payload['tanggal_pesan'] = date('Y-m-d H:i:s');
        }
        if ($this->db->field_exists('updated_at', $this->t_pesanan)) {
            $payload['updated_at'] = date('Y-m-d H:i:s');
        }
        if ($this->db->field_exists('tgl_update', $this->t_pesanan)) {
            $payload['tgl_update'] = date('Y-m-d H:i:s');
        }

        $payload = $this->filter_by_table_fields($this->t_pesanan, $payload);
        if (empty($payload)) return;

        $this->apply_where_id_pesanan($this->t_pesanan, $id_pesanan);
        $this->db->update($this->t_pesanan, $payload);
    }

    private function log_status_pesanan(int $id_pesanan, string $status): void
    {
        if (!$this->db->table_exists('status_pesanan')) return;

        $payload = [
            'id_pesanan'   => $id_pesanan,
            'status'       => $status,
            'waktu_update' => date('Y-m-d H:i:s'),
        ];

        $payload = $this->filter_by_table_fields('status_pesanan', $payload);
        if (empty($payload)) return;

        $this->db->insert('status_pesanan', $payload);
    }

    private function push_to_kasir_dapur(int $id_pesanan): void
    {
        $this->set_pesanan_status($id_pesanan, 'diproses');
        $this->log_status_pesanan($id_pesanan, 'diproses');
    }

    public function mark_cod_to_kasir_dapur(int $id_pesanan): void
    {
        // Pastikan tabel_pembayaran ada row pending cash (kalau ada tabelnya)
        $this->init_tabel_pembayaran_pending($id_pesanan, 'cash');

        // Dorong ke kasir/dapur
        $this->push_to_kasir_dapur($id_pesanan);
    }

    public function get_pesanan_pembayaran(int $member_id, int $id_pesanan): ?array
    {
        if (!$this->db->table_exists($this->t_pesanan)) return null;

        $pesanan = null;

        $member_cols = $this->member_owner_cols($this->t_pesanan);
        if (!empty($member_cols)) {
            $this->db->from($this->t_pesanan);
            $this->apply_where_id_pesanan($this->t_pesanan, $id_pesanan);

            $this->db->group_start();
            foreach ($member_cols as $i => $col) {
                if ($i === 0) $this->db->where($col, $member_id);
                else         $this->db->or_where($col, $member_id);
            }
            $this->db->group_end();

            $pesanan = $this->db->get()->row_array();
        }

        if (!$pesanan) {
            $pelanggan_id   = (int)($this->session->userdata('member_pelanggan_id') ?? 0);
            $pelanggan_cols = $this->pelanggan_owner_cols($this->t_pesanan);

            if ($pelanggan_id > 0 && !empty($pelanggan_cols)) {
                $this->db->from($this->t_pesanan);
                $this->apply_where_id_pesanan($this->t_pesanan, $id_pesanan);

                $this->db->group_start();
                foreach ($pelanggan_cols as $i => $col) {
                    if ($i === 0) $this->db->where($col, $pelanggan_id);
                    else         $this->db->or_where($col, $pelanggan_id);
                }
                $this->db->group_end();

                $pesanan = $this->db->get()->row_array();
            }
        }

        if (!$pesanan) return null;

        $items = $this->get_items($id_pesanan);

        $total = 0;
        foreach (['total_amount', 'total_harga', 'total', 'grand_total', 'total_transaksi'] as $k) {
            if (isset($pesanan[$k]) && is_numeric($pesanan[$k])) {
                $total = (int)$pesanan[$k];
                break;
            }
        }
        if ($total <= 0 && !empty($items)) {
            foreach ($items as $it) $total += (int)$it['subtotal'];
        }

        return [
            'pesanan' => $pesanan,
            'items'   => $items,
            'total'   => $total,
        ];
    }

    private function get_items(int $id_pesanan): array
    {
        $detailTable = $this->t_pesanan_detail;
        if (!$this->db->table_exists($detailTable)) return [];

        $alias = 'dp';
        $menuTable = 'menu';

        $this->db->from($detailTable . ' ' . $alias);

        $canJoinMenu =
            $this->db->table_exists($menuTable) &&
            $this->db->field_exists('id_menu', $detailTable) &&
            $this->db->field_exists('id_menu', $menuTable);

        if ($canJoinMenu) {
            $this->db->select($alias . '.*', false);
            $this->db->select('m.nama_menu AS _menu_nama');
            if ($this->db->field_exists('harga', $menuTable)) {
                $this->db->select('m.harga AS _menu_harga');
            }
            $this->db->join($menuTable . ' m', 'm.id_menu = ' . $alias . '.id_menu', 'left');
        } else {
            $this->db->select('*');
        }

        $this->apply_where_id_pesanan($detailTable, $id_pesanan);
        $rows = $this->db->get()->result_array();

        $out = [];
        foreach ($rows as $r) {
            $nama = (string)(
                $r['nama_menu'] ??
                $r['nama_item'] ??
                $r['_menu_nama'] ??
                $r['nama'] ??
                $r['menu'] ??
                'Item'
            );

            $qty  = (int)($r['qty'] ?? $r['jumlah'] ?? 1);

            $subtotal = 0;
            foreach (['subtotal', 'total', 'jumlah_harga'] as $k) {
                if (isset($r[$k]) && is_numeric($r[$k])) { $subtotal = (int)$r[$k]; break; }
            }

            $harga = 0;
                if (isset($r['harga']) && is_numeric($r['harga'])) {
                    $harga = (int)$r['harga'];
                } elseif (isset($r['_menu_harga']) && is_numeric($r['_menu_harga'])) {
                    $harga = (int)$r['_menu_harga'];
                }


            $out[] = [
                'nama'     => $nama,
                'qty'      => max(1, $qty),
                'subtotal' => $subtotal,
            ];
        }

        return $out;
    }


    public function set_metode_pembayaran(int $member_id, int $id_pesanan, string $metode, string $bank = ''): array
    {
        if (!$this->db->table_exists($this->t_pesanan)) {
            return ['ok' => false, 'msg' => 'Tabel pesanan tidak ditemukan.'];
        }

        $paket = $this->get_pesanan_pembayaran($member_id, $id_pesanan);
        if (!$paket) {
            return ['ok' => false, 'msg' => 'Pesanan tidak ditemukan / bukan milik kamu.'];
        }

        $payload = [
            'metode_pembayaran' => $metode,
            'payment_method'    => $metode,
            'pembayaran'        => $metode,
            'metode_bayar'      => $metode,
            'bank'              => $bank,
            'nama_bank'         => $bank,
            'status_pembayaran' => 'menunggu_konfirmasi',
            'status_bayar'      => 'menunggu_konfirmasi',
            'status'            => 'menunggu_bayar',
            'updated_at'        => date('Y-m-d H:i:s'),
            'tgl_update'        => date('Y-m-d H:i:s'),
        ];

        $payload = $this->filter_by_table_fields($this->t_pesanan, $payload);
        if (empty($payload)) return ['ok' => true];

        $this->apply_where_id_pesanan($this->t_pesanan, $id_pesanan);
        $this->db->update($this->t_pesanan, $payload);

        return ['ok' => true];
    }


    public function save_midtrans_token(int $member_id, int $id_pesanan, string $order_id, string $token): array
    {
        if (!$this->db->table_exists($this->t_pesanan)) return ['ok' => false];

        $paket = $this->get_pesanan_pembayaran($member_id, $id_pesanan);
        if (!$paket) return ['ok' => false];

        $payload = [
            'midtrans_order_id' => $order_id,
            'order_id_midtrans' => $order_id,
            'snap_token'        => $token,
            'midtrans_token'    => $token,
            'status_bayar'      => 'pending',
            'status_pembayaran' => 'pending',
            'metode_pembayaran' => 'midtrans',
            'payment_method'    => 'midtrans',
            'pembayaran'        => 'midtrans',
            'metode_bayar'      => 'midtrans',
            'updated_at'        => date('Y-m-d H:i:s'),
            'tgl_update'        => date('Y-m-d H:i:s'),
        ];

        $payload = $this->filter_by_table_fields($this->t_pesanan, $payload);
        if (empty($payload)) return ['ok' => true];

        $this->apply_where_id_pesanan($this->t_pesanan, $id_pesanan);
        $this->db->update($this->t_pesanan, $payload);

        return ['ok' => true];
    }

    public function update_status_by_midtrans_order(string $order_id, string $status_bayar, array $raw): array
    {
        if (!$this->db->table_exists($this->t_pesanan)) return ['ok' => false];

        $has_midtrans_order = $this->db->field_exists('midtrans_order_id', $this->t_pesanan);
        $has_order_midtrans = $this->db->field_exists('order_id_midtrans', $this->t_pesanan);

        if (!$has_midtrans_order && !$has_order_midtrans) return ['ok' => true];

        $payload = [
            'status_bayar'      => $status_bayar,
            'status_pembayaran' => $status_bayar,
            'payment_type'      => (string)($raw['payment_type'] ?? ''),
            'tipe_pembayaran'   => (string)($raw['payment_type'] ?? ''),
            'raw_midtrans'      => json_encode($raw),
            'midtrans_raw'      => json_encode($raw),
            'updated_at'        => date('Y-m-d H:i:s'),
            'tgl_update'        => date('Y-m-d H:i:s'),
        ];

        $payload = $this->filter_by_table_fields($this->t_pesanan, $payload);
        if (empty($payload)) return ['ok' => true];

        $this->db->group_start();
        if ($has_midtrans_order) $this->db->where('midtrans_order_id', $order_id);
        if ($has_order_midtrans) {
            if ($has_midtrans_order) $this->db->or_where('order_id_midtrans', $order_id);
            else $this->db->where('order_id_midtrans', $order_id);
        }
        $this->db->group_end();

        $this->db->update($this->t_pesanan, $payload);

        return ['ok' => true];
    }


    public function init_tabel_pembayaran_pending(int $id_pesanan, string $metode = 'midtrans'): void
    {
        if (!$this->db->table_exists($this->t_pembayaran)) return;

        $keyCol = $this->pesanan_key_col($this->t_pembayaran);
        if (!$keyCol) return;

        $row = $this->db->get_where($this->t_pembayaran, [$keyCol => $id_pesanan])->row_array();

        $payload = [
            $keyCol             => $id_pesanan,
            'metode_pembayaran' => $metode,
            'bukti_transfer'    => '',
            'status_pembayaran' => 'pending',
        ];

        $payload = $this->filter_by_table_fields($this->t_pembayaran, $payload);
        if (empty($payload)) return;

        if ($row) $this->db->where($keyCol, $id_pesanan)->update($this->t_pembayaran, $payload);
        else      $this->db->insert($this->t_pembayaran, $payload);
    }


    public function sync_to_transaksi_if_lunas(string $order_id, string $status_bayar, array $raw): void
{
    $id_pesanan = 0;
    if (preg_match('/^PSN-(\d+)-/i', $order_id, $m)) $id_pesanan = (int)$m[1];
    if ($id_pesanan <= 0) return;

    $status_pembayaran = 'pending';
    if ($status_bayar === 'paid')       $status_pembayaran = 'lunas';
    elseif ($status_bayar === 'failed') $status_pembayaran = 'gagal';

    $this->db->trans_start();

  
    if ($this->db->table_exists($this->t_pembayaran)) {
        $payKey = $this->pesanan_key_col($this->t_pembayaran);
        if ($payKey) {
            $row = $this->db->get_where($this->t_pembayaran, [$payKey => $id_pesanan])->row_array();

            $payload = [
                $payKey             => $id_pesanan,
                'metode_pembayaran' => 'midtrans',
                'bukti_transfer'    => '',
                'status_pembayaran' => $status_pembayaran,
            ];

            $payload = $this->filter_by_table_fields($this->t_pembayaran, $payload);

            if (!empty($payload)) {
                if ($row) $this->db->where($payKey, $id_pesanan)->update($this->t_pembayaran, $payload);
                else      $this->db->insert($this->t_pembayaran, $payload);
            }
        }
    }

   
    if ($status_pembayaran === 'lunas') {
        $this->push_to_kasir_dapur($id_pesanan);
    }

    if ($status_pembayaran === 'lunas' && $this->db->table_exists($this->t_transaksi)) {

        $trxKey = $this->pesanan_key_col($this->t_transaksi);
        if ($trxKey) {
            $exists = $this->db->get_where($this->t_transaksi, [$trxKey => $id_pesanan])->row_array();
            if ($exists) {
                $this->db->trans_complete();
                return;
            }
        }

        $this->db->from($this->t_pesanan);
        $this->apply_where_id_pesanan($this->t_pesanan, $id_pesanan);
        $pesanan = $this->db->get()->row_array();

        if ($pesanan) {

            $id_user = (int)($this->session->userdata('id_user') ?? 0);

            if ($id_user <= 0) {
                foreach (['id_user','user_id','member_id','id_member'] as $k) {
                    if (isset($pesanan[$k]) && is_numeric($pesanan[$k])) {
                        $id_user = (int)$pesanan[$k];
                        break;
                    }
                }
            }

            if ($id_user > 0 && $this->db->table_exists('user') && $this->db->field_exists('id_user', 'user')) {
                $u = $this->db->get_where('user', ['id_user' => $id_user])->row_array();
                if (!$u) $id_user = 0;
            } else {
                $id_user = 0;
            }

            $total = 0;
            foreach (['total_amount','total_harga','total','grand_total'] as $k) {
                if (isset($pesanan[$k]) && is_numeric($pesanan[$k])) { $total = (int)$pesanan[$k]; break; }
            }
            if ($total <= 0) {
                $items = $this->get_items($id_pesanan);
                foreach ($items as $it) $total += (int)$it['subtotal'];
            }

            if ($id_user <= 0) {
                $this->db->trans_complete();
                return;
            }

            $trx = [
                ($trxKey ?: 'id_pesanan') => $id_pesanan,
                'id_user'           => $id_user,
                'tanggal_transaksi' => date('Y-m-d H:i:s'),
                'total_transaksi'   => $total,
            ];

            $trx = $this->filter_by_table_fields($this->t_transaksi, $trx);

            if (!empty($trx)) {
                $this->db->insert($this->t_transaksi, $trx);
            }
        }
    }

    $this->db->trans_complete();
}

}
