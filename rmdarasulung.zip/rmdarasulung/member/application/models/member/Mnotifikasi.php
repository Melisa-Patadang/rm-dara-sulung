<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class Mnotifikasi extends CI_Model
{
    private string $t_pesanan    = 'pesanan';
    private string $t_detail     = 'pesanan_detail';
    private string $t_menu       = 'menu';
    private string $t_status_log = 'status_pesanan';

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
        $this->load->library('session');

        // beberapa project memakai detail_pesanan
        if ($this->db->table_exists('detail_pesanan')) {
            $this->t_detail = 'detail_pesanan';
        }
    }


    private function normalize_status(string $s): string
    {
        $s = strtolower(trim($s));
        $s = str_replace([' ', '-'], '_', $s);

        if ($s === 'siap_diambil') $s = 'siap_ambil';
        if ($s === 'siap') $s = 'siap_ambil';
        if ($s === 'ready') $s = 'siap_ambil';

        return $s;
    }

    private function status_label(string $s): string
    {
        $s = $this->normalize_status($s);

        if ($s === 'diproses') return 'Diproses';
        if ($s === 'siap_ambil') return 'Siap diambil';
        if ($s === 'selesai') return 'Selesai';
        if ($s === 'baru') return 'Baru';
        if ($s === 'menunggu_bayar') return 'Menunggu bayar';

        return $s;
    }

    private function status_col(): ?string
    {
        if ($this->db->field_exists('status_pesanan', $this->t_pesanan)) return 'status_pesanan';
        if ($this->db->field_exists('status', $this->t_pesanan)) return 'status';
        return null;
    }

    private function waktu_pesan_col(): ?string
    {
        foreach (['tanggal_pesanan','tanggal_pesan', 'tanggal', 'created_at', 'tgl_pesan'] as $c) {
            if ($this->db->field_exists($c, $this->t_pesanan)) return $c;
        }
        return null;
    }

    private function apply_where_owner(int $member_id): void
    {
        // sebagian sistem menyimpan pelanggan_id di session
        $pelanggan_id = (int)($this->session->userdata('member_pelanggan_id') ?? 0);

        $owner_cols = [];
        foreach (['member_id', 'id_member', 'user_id', 'id_user'] as $c) {
            if ($this->db->field_exists($c, $this->t_pesanan)) $owner_cols[] = $c;
        }

        $pel_cols = [];
        foreach (['id_pelanggan', 'pelanggan_id'] as $c) {
            if ($this->db->field_exists($c, $this->t_pesanan)) $pel_cols[] = $c;
        }

        if (empty($owner_cols) && empty($pel_cols)) return;

        $this->db->group_start();
        $added = false;

        foreach ($owner_cols as $c) {
            if (!$added) $this->db->where($c, $member_id);
            else         $this->db->or_where($c, $member_id);
            $added = true;
        }

        if ($pelanggan_id > 0) {
            foreach ($pel_cols as $c) {
                if (!$added) $this->db->where($c, $pelanggan_id);
                else         $this->db->or_where($c, $pelanggan_id);
                $added = true;
            }
        }

        $this->db->group_end();
    }

    private function latest_log_map(array $ids): array
    {
        $ids = array_values(array_filter(array_map('intval', $ids), fn($v) => $v > 0));
        if (empty($ids)) return [];
        if (!$this->db->table_exists($this->t_status_log)) return [];

        $time_col = $this->db->field_exists('waktu_update', $this->t_status_log) ? 'waktu_update' :
                    ($this->db->field_exists('waktu', $this->t_status_log) ? 'waktu' :
                    ($this->db->field_exists('created_at', $this->t_status_log) ? 'created_at' : ''));

        $id_col   = $this->db->field_exists('id_status', $this->t_status_log) ? 'id_status' : '';

        $this->db->from($this->t_status_log);
        $this->db->where_in('id_pesanan', $ids);
        if ($id_col !== '') $this->db->order_by($id_col, 'DESC');
        elseif ($time_col !== '') $this->db->order_by($time_col, 'DESC');
        else $this->db->order_by('id_pesanan', 'DESC');

        $rows = $this->db->get()->result_array();
        if (empty($rows)) return [];

        $out = [];
        foreach ($rows as $r) {
            $pid = (int)($r['id_pesanan'] ?? 0);
            if ($pid <= 0) continue;
            if (isset($out[$pid])) continue;

            $out[$pid] = [
                'status' => (string)($r['status'] ?? ''),
                'waktu'  => (string)($time_col !== '' ? ($r[$time_col] ?? '') : ''),
            ];
        }
        return $out;
    }

   public function get_notif_count(int $member_id): int
    {
    $paket = $this->get_latest_panel($member_id);
    $id    = (int)($paket['id_pesanan'] ?? 0);
    if ($id <= 0) return 0;

    $st = $this->normalize_status((string)($paket['status'] ?? ''));
    return in_array($st, ['diproses','siap_ambil','selesai'], true) ? 1 : 0;
    }


    public function get_latest_panel(int $member_id): array
    {
        if (!$this->db->table_exists($this->t_pesanan)) {
            return ['id_pesanan'=>0,'status'=>'','timeline'=>[],'items'=>[]];
        }

        $statusCol = $this->status_col();
        $waktuCol  = $this->waktu_pesan_col();

        $this->db->from($this->t_pesanan);
        $this->apply_where_owner($member_id);
        $this->db->select('id_pesanan');
        if ($statusCol) $this->db->select($statusCol . ' AS status');
        if ($waktuCol)  $this->db->select($waktuCol  . ' AS waktu_pesan');
aru
        if ($statusCol) {
            $this->db->where_in($statusCol, ['diproses','siap_ambil','selesai']);
            $this->db->order_by("CASE {$statusCol} WHEN 'diproses' THEN 0 WHEN 'siap_ambil' THEN 1 WHEN 'selesai' THEN 2 ELSE 3 END", 'ASC', false);
        }
        $this->db->order_by('id_pesanan', 'DESC');
        $this->db->limit(1);

        $row = $this->db->get()->row_array();
        if (!$row) {
            return ['id_pesanan'=>0,'status'=>'','timeline'=>[],'items'=>[]];
        }

        $id_pesanan = (int)($row['id_pesanan'] ?? 0);
        $status     = $this->normalize_status((string)($row['status'] ?? ''));

        // fallback status dari log terakhir jika status pesanan kosong
        if ($status === '') {
            $last = $this->latest_log_map([$id_pesanan]);
            $status = $this->normalize_status((string)($last[$id_pesanan]['status'] ?? ''));
        }

        $timeline = $this->get_timeline($id_pesanan, $row);
        $items    = $this->get_items($id_pesanan);

        // fallback status dari timeline terakhir
        if ($status === '' && !empty($timeline)) {
            $last = end($timeline);
            $status = $this->normalize_status((string)($last['status_norm'] ?? ''));
            reset($timeline);
        }

        return [
            'id_pesanan' => $id_pesanan,
            'status'     => $status,
            'timeline'   => $timeline,
            'items'      => $items,
        ];
    }

    private function get_timeline(int $id_pesanan, array $pesanan_row): array
    {
        $events = [];

        if ($this->db->table_exists($this->t_status_log)) {
            $this->db->from($this->t_status_log);
            $this->db->where('id_pesanan', $id_pesanan);

            if ($this->db->field_exists('id_status', $this->t_status_log)) {
                $this->db->order_by('id_status', 'ASC');
            } elseif ($this->db->field_exists('waktu_update', $this->t_status_log)) {
                $this->db->order_by('waktu_update', 'ASC');
            }

            $rows = $this->db->get()->result_array();
            foreach ($rows as $r) {
                $st = (string)($r['status'] ?? ($r['status_label'] ?? ($r['keterangan'] ?? '')));
                $events[] = [
                    'waktu'        => (string)($r['waktu_update'] ?? ($r['waktu'] ?? ($r['created_at'] ?? ''))),
                    'status_norm'  => $this->normalize_status($st),
                    'status_label' => $this->status_label($st),
                ];
            }
        }

        $statusCol = $this->status_col();
        $current   = $statusCol ? (string)($pesanan_row[$statusCol] ?? '') : '';
        $current   = $this->normalize_status($current);

        $has_selesai = false;
        foreach ($events as $e) {
            if (($e['status_norm'] ?? '') === 'selesai') { $has_selesai = true; break; }
        }
        if ($current === 'selesai' && !$has_selesai) {
            $t = '';
            foreach (['updated_at','tgl_update','tanggal_pesanan','tanggal_pesan','tanggal','created_at'] as $c) {
                if (isset($pesanan_row[$c]) && (string)$pesanan_row[$c] !== '') { $t = (string)$pesanan_row[$c]; break; }
            }
            if ($t === '') $t = date('Y-m-d H:i:s');

            $events[] = [
                'waktu'        => $t,
                'status_norm'  => 'selesai',
                'status_label' => 'Selesai',
            ];
        }

        return $events;
    }

    private function get_items(int $id_pesanan): array
    {
        if (!$this->db->table_exists($this->t_detail)) return [];

        $alias = 'dp';
        $this->db->from($this->t_detail . ' ' . $alias);
        $this->db->select($alias . '.*', false);

        $canJoinMenu =
            $this->db->table_exists($this->t_menu) &&
            $this->db->field_exists('id_menu', $this->t_detail) &&
            $this->db->field_exists('id_menu', $this->t_menu);

        if ($canJoinMenu) {
            $this->db->select('m.nama_menu AS _menu_nama');
            if ($this->db->field_exists('foto', $this->t_menu))  $this->db->select('m.foto AS _menu_foto');
            if ($this->db->field_exists('gambar', $this->t_menu)) $this->db->select('m.gambar AS _menu_gambar');
            $this->db->join($this->t_menu . ' m', 'm.id_menu = ' . $alias . '.id_menu', 'left');
        }

        if ($this->db->field_exists('id_pesanan', $this->t_detail)) {
            $this->db->where($alias . '.id_pesanan', $id_pesanan);
        } elseif ($this->db->field_exists('pesanan_id', $this->t_detail)) {
            $this->db->where($alias . '.pesanan_id', $id_pesanan);
        } else {
            return [];
        }

        $rows = $this->db->get()->result_array();
        if (empty($rows)) return [];

        $out = [];
        foreach ($rows as $r) {
            $nama = (string)(
                $r['nama_menu'] ??
                $r['nama_item'] ??
                $r['_menu_nama'] ??
                'Item'
            );

            $qty = (int)($r['qty'] ?? $r['jumlah'] ?? 1);
            if ($qty <= 0) $qty = 1;

            
            $src  = trim((string)($r['foto'] ?? $r['gambar'] ?? $r['_menu_foto'] ?? $r['_menu_gambar'] ?? ''));

          
            if ($src === '') {
                
                $foto = 'assets/img/logodarasulung.jpeg';
            } elseif (preg_match('~^https?://~i', $src)) {
                $foto = $src;
            } elseif (strpos($src, '/') !== false) {
               
                $foto = $src;
            } else {
               
                $foto = '../admin/uploads/menu/' . $src;
            }

            $out[] = [
                'nama' => $nama,
                'qty'  => $qty,
                'foto' => $foto,
            ];
        }

        return $out;
    }
}
