<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class Mnotif extends CI_Model
{
    private string $t_status  = 'status_pesanan';
    private string $t_pesanan = 'pesanan';

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    private function has_field(string $table, string $field): bool
    {
        return $this->db->field_exists($field, $table);
    }

    private function first_field(string $table, array $candidates): string
    {
        foreach ($candidates as $f) {
            if ($this->has_field($table, $f)) return $f;
        }
        return '';
    }

    
    private function owner_col(): string
    {
        return $this->first_field($this->t_pesanan, [
            'member_id', 'id_member',
            'id_user', 'user_id',
            'id_pelanggan', 'pelanggan_id'
        ]);
    }

    private function status_pk_col(): string
    {
       
        return $this->first_field($this->t_status, ['id_status', 'status_id', 'id']);
    }

    private function status_time_col(): string
    {
        return $this->first_field($this->t_status, ['waktu_update', 'created_at', 'waktu', 'tanggal']);
    }

    private function status_label_col(): string
    {
        return $this->first_field($this->t_status, ['status', 'status_label', 'keterangan']);
    }

    private function pesanan_id_col(): string
    {
        return $this->first_field($this->t_pesanan, ['id_pesanan', 'pesanan_id']);
    }

    private function status_pesanan_id_col(): string
    {
        return $this->first_field($this->t_status, ['id_pesanan', 'pesanan_id']);
    }

    private function base_query_for_member(int $member_id): void
    {
        
        if (!$this->db->table_exists($this->t_status) || !$this->db->table_exists($this->t_pesanan)) {
         
            return;
        }

        $pk   = $this->status_pk_col();
        $pidS = $this->status_pesanan_id_col();
        $pidP = $this->pesanan_id_col();
        $own  = $this->owner_col();

        if ($pk === '' || $pidS === '' || $pidP === '' || $own === '') {
            return;
        }

      
        $this->db->from($this->t_status . ' sp');
        $this->db->join($this->t_pesanan . ' p', 'p.' . $pidP . ' = sp.' . $pidS, 'inner');
        $this->db->where('p.' . $own, (int)$member_id);
    }

    public function get_max_status_id(int $member_id): int
    {
        if (!$this->db->table_exists($this->t_status) || !$this->db->table_exists($this->t_pesanan)) return 0;

        $pk = $this->status_pk_col();
        if ($pk === '') return 0;

        $this->base_query_for_member($member_id);
        $row = $this->db->select_max('sp.' . $pk, 'mx')->get()->row();
        return (int)($row->mx ?? 0);
    }

    public function count_new(int $member_id, int $last_seen_id): int
    {
        if (!$this->db->table_exists($this->t_status) || !$this->db->table_exists($this->t_pesanan)) return 0;

        $pk = $this->status_pk_col();
        if ($pk === '') return 0;

        $this->base_query_for_member($member_id);
        $this->db->where('sp.' . $pk . ' >', (int)$last_seen_id);
        return (int)$this->db->count_all_results();
    }

    public function latest(int $member_id, int $limit = 8, int $last_seen_id = 0): array
    {
        if (!$this->db->table_exists($this->t_status) || !$this->db->table_exists($this->t_pesanan)) return [];

        $pk   = $this->status_pk_col();
        $pidS = $this->status_pesanan_id_col();
        $time = $this->status_time_col();
        $st   = $this->status_label_col();
        if ($pk === '' || $pidS === '' || $st === '') return [];

        $sel = [
            'sp.' . $pk . ' AS id_status',
            'sp.' . $pidS . ' AS id_pesanan',
            'sp.' . $st . ' AS status'
        ];
        if ($time !== '') $sel[] = 'sp.' . $time . ' AS waktu_update';

        $this->base_query_for_member($member_id);
        $rows = $this->db
            ->select(implode(', ', $sel))
            ->order_by('sp.' . $pk, 'DESC')
            ->limit((int)$limit)
            ->get()
            ->result_array();

        $items = [];
        foreach ($rows as $r) {
            $id_status  = (int)($r['id_status'] ?? 0);
            $id_pesanan = (int)($r['id_pesanan'] ?? 0);
            $status     = strtolower(trim((string)($r['status'] ?? '')));
            $waktu_raw  = (string)($r['waktu_update'] ?? '');

            $desc = $this->map_status_desc($status);
            $time_fmt = '';
            if ($waktu_raw !== '') {
                $ts = strtotime($waktu_raw);
                if ($ts) $time_fmt = date('d/m/Y H:i', $ts);
            }

            $items[] = [
                'id'     => $id_status,
                'title'  => 'Pesanan #' . $id_pesanan,
                'desc'   => $desc,
                'time'   => $time_fmt,
                'url'    => site_url('member/tracking_pesanan/lihat/' . $id_pesanan),
                'is_new' => ($id_status > (int)$last_seen_id) ? 1 : 0,
            ];
        }

        return $items;
    }

    private function map_status_desc(string $status): string
    {
        $status = str_replace([' ', '-'], '_', strtolower(trim($status)));
        if ($status === 'siap_diambil') $status = 'siap_ambil';

        switch ($status) {
            case 'diproses':
                return 'Pesanan sedang diproses.';
            case 'siap_ambil':
                return 'Pesanan siap diambil.';
            case 'selesai':
                return 'Pesanan selesai.';
            default:
                return $status !== '' ? ('Update status: ' . $status) : 'Update pesanan.';
        }
    }
}
