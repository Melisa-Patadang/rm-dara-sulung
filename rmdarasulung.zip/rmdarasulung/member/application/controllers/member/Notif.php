<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Notif extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();

        date_default_timezone_set('Asia/Jakarta');
        $this->load->library('session');
        $this->load->helper(['url']);
        $this->load->database();

        $this->load->model('member/Mnotif', 'mnotif');
    }

    private function member_id(): int
    {
        return (int)$this->session->userdata('member_id');
    }

    private function get_last_seen_id(int $member_id): int
    {
        $key  = 'member_notif_last_seen_status_id';
        $last = (int)$this->session->userdata($key);

        $max = (int)$this->mnotif->get_max_status_id($member_id);
        if ($last > $max) {
            $last = 0;
            $this->session->set_userdata($key, $last);
        }

        if ($last <= 0) {
            $last = $max > 0 ? $max : 0;
            $this->session->set_userdata($key, $last);
        }

        return $last;
    }

    public function count()
    {
        $member_id = $this->member_id();
        if ($member_id <= 0) {
            return $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode(['count' => 0]));
        }

        $last  = $this->get_last_seen_id($member_id);
        $count = (int)$this->mnotif->count_new($member_id, $last);

        return $this->output
            ->set_content_type('application/json')
            ->set_output(json_encode(['count' => $count]));
    }
    public function list()
    {
        $member_id = $this->member_id();
        if ($member_id <= 0) {
            return $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode(['items' => []]));
        }

        $last  = $this->get_last_seen_id($member_id);
        $items = $this->mnotif->latest($member_id, 8, $last);

        return $this->output
            ->set_content_type('application/json')
            ->set_output(json_encode(['items' => $items]));
    }

    public function seen()
    {
        $member_id = $this->member_id();
        if ($member_id <= 0) {
            return $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode(['ok' => true, 'last_seen_id' => 0]));
        }

        $key    = 'member_notif_last_seen_status_id';
        $max_id = (int)$this->mnotif->get_max_status_id($member_id);
        $this->session->set_userdata($key, $max_id);

        return $this->output
            ->set_content_type('application/json')
            ->set_output(json_encode(['ok' => true, 'last_seen_id' => $max_id]));
    }
}
