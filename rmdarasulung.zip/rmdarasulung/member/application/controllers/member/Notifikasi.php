<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Notifikasi extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        date_default_timezone_set('Asia/Jakarta');

        $this->load->database();
        $this->load->helper(['url']);
        $this->load->library(['session']);

        if (!$this->session->userdata('member_id')) {
         
            show_error('Unauthorized', 401);
        }

        $this->load->model('member/Mnotifikasi', 'mnotif');
    }

    public function count_json()
    {
        $member_id = (int)$this->session->userdata('member_id');
        $count     = (int)$this->mnotif->get_notif_count($member_id);

        return $this->output
            ->set_content_type('application/json')
            ->set_output(json_encode(['count' => $count]));
    }

  
    public function panel_html()
    {
        $member_id = (int)$this->session->userdata('member_id');
        $paket     = $this->mnotif->get_latest_panel($member_id);

        $data = [
            'id_pesanan' => (int)($paket['id_pesanan'] ?? 0),
            'status'     => (string)($paket['status'] ?? ''),
            'timeline'   => (array)($paket['timeline'] ?? []),
            'items'      => (array)($paket['items'] ?? []),
        ];

        // HTML parsial saja
        $this->load->view('member/notifikasi/panel', $data);
    }
}
