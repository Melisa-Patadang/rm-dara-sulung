<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require_once APPPATH . 'third_party/Midtrans-php/Midtrans/Config.php';
require_once APPPATH . 'third_party/Midtrans-php/Midtrans/ApiRequestor.php';
require_once APPPATH . 'third_party/Midtrans-php/Midtrans/Sanitizer.php';
require_once APPPATH . 'third_party/Midtrans-php/Midtrans/Transaction.php';
require_once APPPATH . 'third_party/Midtrans-php/Midtrans/Snap.php';

use Midtrans\Config;
use Midtrans\Snap;
use Midtrans\Transaction;

class Pembayaran extends CI_Controller
{
    private string $mid_server_key = 'Mid-server-oou3gzfvIoDB_JFCWkbZ9_fm';
    private string $mid_client_key = 'Mid-client-EDIazfG2QqVDEStD';
    private bool   $mid_production = false;

    public function __construct()
    {
        parent::__construct();
        date_default_timezone_set('Asia/Jakarta');

        $this->load->library('session');
        $this->load->helper(['url', 'form']);
        $this->load->database();

        $this->load->model('member/Mpembayaran', 'bayar');

        $method = $this->router->fetch_method();
        if (!in_array($method, ['notification_midtrans', 'snap_token', 'finalize_midtrans'], true)) {
            if (!$this->session->userdata('member_id')) {
                redirect('member/login');
            }
        }

        $this->mid_server_key = trim($this->mid_server_key);
        $this->mid_client_key = trim($this->mid_client_key);

        Config::$serverKey    = $this->mid_server_key;
        Config::$isProduction = $this->mid_production;
        Config::$isSanitized  = true;
        Config::$is3ds        = true;
    }

    public function index($id_pesanan = null)
    {
        $member_id  = (int)$this->session->userdata('member_id');
        $id_pesanan = (int)$id_pesanan;

        if ($id_pesanan <= 0) {
            $this->session->set_flashdata('pesan_gagal', 'ID pesanan tidak valid.');
            redirect('member/dashboard');
        }

        $paket = $this->bayar->get_pesanan_pembayaran($member_id, $id_pesanan);
        if (!$paket) {
            $this->session->set_flashdata('pesan_gagal', 'Pesanan tidak ditemukan / bukan milik kamu.');
            redirect('member/dashboard');
        }

        $data = [
            'nama'           => (string)$this->session->userdata('member_nama'),
            'id_pesanan'     => $id_pesanan,
            'pesanan'        => $paket['pesanan'],
            'items'          => $paket['items'],
            'total'          => (int)$paket['total'],
            'mid_client_key' => $this->mid_client_key,
            'mid_production' => $this->mid_production,
        ];

        $this->load->view('part/topnav', $data);
        $this->load->view('member/pembayaran', $data);
        $this->load->view('part/footer', $data);
    }

    public function submit($id_pesanan = null)
    {
        $member_id  = (int)$this->session->userdata('member_id');
        $id_pesanan = (int)$id_pesanan;

        if ($id_pesanan <= 0) {
            $this->session->set_flashdata('pesan_gagal', 'ID pesanan tidak valid.');
            redirect('member/dashboard');
        }

        $paket = $this->bayar->get_pesanan_pembayaran($member_id, $id_pesanan);
        if (!$paket) {
            $this->session->set_flashdata('pesan_gagal', 'Pesanan tidak ditemukan / bukan milik kamu.');
            redirect('member/dashboard');
        }

        $metode = trim((string)$this->input->post('metode', true));
        if (!in_array($metode, ['midtrans', 'cod'], true)) {
            $this->session->set_flashdata('pesan_gagal', 'Silakan pilih metode pembayaran.');
            redirect('member/pembayaran/index/' . $id_pesanan);
        }

       
        $res = $this->bayar->set_metode_pembayaran($member_id, $id_pesanan, $metode, '');

        if (empty($res['ok'])) {
            $this->session->set_flashdata('pesan_gagal', $res['msg'] ?? 'Gagal menyimpan metode pembayaran.');
            redirect('member/pembayaran/index/' . $id_pesanan);
        }

        if ($metode === 'midtrans') {
            // midtrans: buat row pending pembayaran
            $this->bayar->init_tabel_pembayaran_pending($id_pesanan, 'midtrans');

            $this->session->set_flashdata('pesan_berhasil', 'Metode pembayaran Midtrans tersimpan.');
            redirect('member/pembayaran/index/' . $id_pesanan);
            return;
        }

        $this->bayar->mark_cod_to_kasir_dapur($id_pesanan);

        $this->session->set_flashdata('pesan_berhasil', 'Pesanan COD berhasil dibuat dan masuk antrian kasir/dapur.');
        redirect('member/dashboard');
    }

    public function snap_token($id_pesanan = null)
    {
        $this->output->set_content_type('application/json');

        $member_id  = (int)$this->session->userdata('member_id');
        $id_pesanan = (int)$id_pesanan;

        if ($id_pesanan <= 0) return $this->_json(['ok'=>false,'msg'=>'ID pesanan tidak valid.'], 400);
        if ($member_id <= 0)  return $this->_json(['ok'=>false,'msg'=>'Session habis. Silakan login ulang.'], 401);

        $paket = $this->bayar->get_pesanan_pembayaran($member_id, $id_pesanan);
        if (!$paket) return $this->_json(['ok'=>false,'msg'=>'Pesanan tidak ditemukan / bukan milik kamu.'], 404);

        $gross_amount = (int)$paket['total'];
        if ($gross_amount <= 0) return $this->_json(['ok'=>false,'msg'=>'Total tidak valid.'], 400);

        $order_id = 'PSN-' . $id_pesanan . '-' . date('YmdHis');

        $params = [
            'transaction_details' => [
                'order_id'     => $order_id,
                'gross_amount' => $gross_amount,
            ],
            'customer_details' => [
                'first_name' => (string)$this->session->userdata('member_nama') ?: 'Member',
            ],
        ];

        try {
            $token = Snap::getSnapToken($params);

            $this->bayar->save_midtrans_token($member_id, $id_pesanan, $order_id, $token);
            $this->bayar->init_tabel_pembayaran_pending($id_pesanan, 'midtrans');

            return $this->_json(['ok'=>true,'token'=>$token,'order_id'=>$order_id], 200);
        } catch (Exception $e) {
            return $this->_json(['ok'=>false,'msg'=>$e->getMessage()], 500);
        }
    }

    public function finalize_midtrans($id_pesanan = null)
    {
        $member_id  = (int)$this->session->userdata('member_id');
        $id_pesanan = (int)$id_pesanan;

        if ($member_id <= 0) {
            $this->session->set_flashdata('pesan_gagal', 'Session habis. Silakan login ulang.');
            redirect('member/login');
        }

        if ($id_pesanan <= 0) {
            $this->session->set_flashdata('pesan_gagal', 'ID pesanan tidak valid.');
            redirect('member/dashboard');
        }

        $order_id = trim((string)$this->input->get('order_id', true));
        if ($order_id === '') $order_id = trim((string)$this->input->post('order_id', true));

        if ($order_id === '') {
            $this->session->set_flashdata('pesan_gagal', 'order_id belum dikirim.');
            redirect('member/pembayaran/index/' . $id_pesanan);
        }

        if (!preg_match('/^PSN-(\d+)-/i', $order_id, $m)) {
            $this->session->set_flashdata('pesan_gagal', 'Format order_id tidak valid.');
            redirect('member/pembayaran/index/' . $id_pesanan);
        }

        if ((int)$m[1] !== $id_pesanan) {
            $this->session->set_flashdata('pesan_gagal', 'order_id tidak sesuai dengan id_pesanan.');
            redirect('member/pembayaran/index/' . $id_pesanan);
        }

        try {
            $st  = Transaction::status($order_id);
            $raw = json_decode(json_encode($st), true);

            $trx_status = (string)($raw['transaction_status'] ?? '');
            $fraud      = (string)($raw['fraud_status'] ?? '');

            $status_bayar = 'pending';
            if ($trx_status === 'settlement') {
                $status_bayar = 'paid';
            } elseif ($trx_status === 'capture') {
                $status_bayar = ($fraud === 'accept') ? 'paid' : 'challenge';
            } elseif (in_array($trx_status, ['deny','cancel','expire','failure'], true)) {
                $status_bayar = 'failed';
            }

            $this->bayar->update_status_by_midtrans_order($order_id, $status_bayar, $raw);
            $this->bayar->sync_to_transaksi_if_lunas($order_id, $status_bayar, $raw);

            if ($status_bayar === 'paid') {
                $this->session->set_flashdata('pesan_berhasil', 'Pembayaran berhasil (LUNAS).');
                redirect('member/dashboard');
                return;
            } elseif ($status_bayar === 'pending') {
                $this->session->set_flashdata('pesan_gagal', 'Pembayaran masih PENDING. Silakan selesaikan pembayaran.');
            } elseif ($status_bayar === 'challenge') {
                $this->session->set_flashdata('pesan_gagal', 'Pembayaran CHALLENGE. Menunggu verifikasi.');
            } else {
                $this->session->set_flashdata('pesan_gagal', 'Pembayaran GAGAL / DIBATALKAN.');
            }

            redirect('member/pembayaran/index/' . $id_pesanan);
        } catch (Exception $e) {
            $this->session->set_flashdata('pesan_gagal', 'Finalize error: ' . $e->getMessage());
            redirect('member/pembayaran/index/' . $id_pesanan);
        }
    }

    public function notification_midtrans()
    {
        $raw  = file_get_contents('php://input');
        $data = json_decode($raw, true);

        if (!is_array($data) || empty($data['order_id'])) {
            return $this->_json(['ok'=>true], 200);
        }

        $order_id     = (string)($data['order_id'] ?? '');
        $status_code  = (string)($data['status_code'] ?? '');
        $gross_amount = (string)($data['gross_amount'] ?? '');
        $signature    = (string)($data['signature_key'] ?? '');

        $expected = hash('sha512', $order_id . $status_code . $gross_amount . $this->mid_server_key);
        if ($signature !== $expected) {
            return $this->_json(['ok'=>false,'msg'=>'Invalid signature'], 403);
        }

        $trx_status = (string)($data['transaction_status'] ?? '');
        $fraud      = (string)($data['fraud_status'] ?? '');

        $status_bayar = 'pending';
        if ($trx_status === 'settlement') {
            $status_bayar = 'paid';
        } elseif ($trx_status === 'capture') {
            $status_bayar = ($fraud === 'accept') ? 'paid' : 'challenge';
        } elseif (in_array($trx_status, ['deny','cancel','expire','failure'], true)) {
            $status_bayar = 'failed';
        }

        $this->bayar->update_status_by_midtrans_order($order_id, $status_bayar, $data);
        $this->bayar->sync_to_transaksi_if_lunas($order_id, $status_bayar, $data);

        return $this->_json(['ok'=>true], 200);
    }

    private function _json(array $payload, int $code = 200)
    {
        $this->output->enable_profiler(false);
        $this->output
            ->set_status_header($code)
            ->set_content_type('application/json', 'utf-8')
            ->set_output(json_encode($payload));

        $this->output->_display();
        exit;
    }
}
