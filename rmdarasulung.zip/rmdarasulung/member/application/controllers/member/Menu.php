<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Menu extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        date_default_timezone_set('Asia/Jakarta');

        $this->load->database();
        $this->load->helper(['url', 'form']);
        $this->load->library(['session']);

        if (!$this->session->userdata('member_id')) {
            redirect('member/login');
        }

        $this->load->model('Mmenu', 'mmenu');
    }

   public function index()
{
  
    $kategori = (string)$this->input->get('kategori', true);
    $q        = (string)$this->input->get('q', true);
    $pg = $this->mmenu->getPaginatedFiltered($kategori, $q);

    $items = isset($pg['menu']) && is_array($pg['menu']) ? $pg['menu'] : [];

    $split = $this->mmenu->split_items($items, 8);

    $data = [
        'nama'        => (string)$this->session->userdata('member_nama'),
        'kategori'    => (string)($pg['kategori'] ?? $kategori),
        'q'           => (string)($pg['q'] ?? $q),

        'items'       => $items,
        'left_items'  => $split['left_items'],
        'right_items' => $split['right_items'],
        'pagination'  => (string)($pg['pagination'] ?? ''),
        'start'       => (int)($pg['start'] ?? 0),

        'cart'        => $this->_cart_get_state(),
    ];

    $this->load->view('part/topnav', $data);
    $this->load->view('member/menu', $data);
    $this->load->view('part/footer', $data);
}
 

    public function cart_add()
    {
        if ($this->input->method() !== 'post') show_404();

        $id  = (int)$this->input->post('id_menu', true);
        $qty = (int)$this->input->post('qty', true);
        if ($qty <= 0) $qty = 1;

        $menu = $this->mmenu->get_by_id($id);
        if (!$menu) return $this->_json(['ok' => false, 'message' => 'Menu tidak ditemukan.']);

        $cart = $this->_cart_get_raw();

        if (!isset($cart[$id])) {
            $cart[$id] = [
                'id_menu' => (int)$menu['id_menu'],
                'nama'    => (string)$menu['nama_menu'],
                'harga'   => (int)$menu['harga'],
                'foto'    => (string)$menu['foto'],
                'qty'     => 0,
            ];
        }

        $cart[$id]['qty'] += $qty;
        $this->_cart_save_raw($cart);

        return $this->_json(['ok' => true, 'cart' => $this->_cart_get_state()]);
    }

    public function cart_update()
    {
        if ($this->input->method() !== 'post') show_404();

        $id  = (int)$this->input->post('id_menu', true);
        $qty = (int)$this->input->post('qty', true);

        $cart = $this->_cart_get_raw();
        if (!isset($cart[$id])) return $this->_json(['ok' => false, 'message' => 'Item tidak ada di keranjang.']);

        if ($qty <= 0) {
            unset($cart[$id]);
        } else {
            $cart[$id]['qty'] = (int)$qty;
        }

        $this->_cart_save_raw($cart);

        return $this->_json(['ok' => true, 'cart' => $this->_cart_get_state()]);
    }

    public function cart_remove()
    {
        if ($this->input->method() !== 'post') show_404();

        $id = (int)$this->input->post('id_menu', true);

        $cart = $this->_cart_get_raw();
        if (isset($cart[$id])) {
            unset($cart[$id]);
            $this->_cart_save_raw($cart);
        }

        return $this->_json(['ok' => true, 'cart' => $this->_cart_get_state()]);
    }

    public function cart_clear()
    {
        if ($this->input->method() !== 'post') show_404();

        $this->session->unset_userdata('member_cart');

        return $this->_json(['ok' => true, 'cart' => $this->_cart_get_state()]);
    }

    private function _cart_get_raw(): array
    {
        $cart = $this->session->userdata('member_cart');
        return is_array($cart) ? $cart : [];
    }

    private function _cart_save_raw(array $cart): void
    {
        $this->session->set_userdata('member_cart', $cart);
    }

    private function _cart_get_state(): array
    {
        $cart = $this->_cart_get_raw();

        $items = [];
        $total_qty = 0;
        $total_amount = 0;

        foreach ($cart as $row) {
            $qty   = (int)($row['qty'] ?? 0);
            $harga = (int)($row['harga'] ?? 0);

            $subtotal = $qty * $harga;

            $items[] = [
                'id_menu'  => (int)($row['id_menu'] ?? 0),
                'nama'     => (string)($row['nama'] ?? ''),
                'harga'    => $harga,
                'foto'     => (string)($row['foto'] ?? ''),
                'qty'      => $qty,
                'subtotal' => $subtotal,
            ];

            $total_qty    += $qty;
            $total_amount += $subtotal;
        }

        return [
            'items'        => $items,
            'total_qty'    => $total_qty,
            'total_amount' => $total_amount,
        ];
    }

    private function _json(array $payload)
    {
        return $this->output
            ->set_content_type('application/json')
            ->set_output(json_encode($payload));
    }
}
