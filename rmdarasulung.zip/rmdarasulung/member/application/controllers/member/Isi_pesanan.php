<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Isi_pesanan extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        date_default_timezone_set('Asia/Jakarta');

        $this->load->library('session');
        $this->load->helper(['url']);
        $this->load->database();

        $this->load->model('member/Misi_pesanan', 'pesan');

        if (!$this->session->userdata('member_id')) {
            redirect('member/login');
        }
    }

    public function index()
    {
        $member_id = (int)$this->session->userdata('member_id');

        $sum = $this->pesan->get_summary_kategori($member_id);

        $data = [
            'nama' => (string)$this->session->userdata('member_nama'),

            'count_makanan' => (int)($sum['makanan'] ?? 0),
            'count_minuman' => (int)($sum['minuman'] ?? 0),
            'count_cemilan' => (int)($sum['cemilan'] ?? 0),

            'prefill_nama'   => (string)($this->session->userdata('member_nama') ?? ''),
            'prefill_alamat' => (string)($this->session->userdata('member_alamat') ?? ''),
            'prefill_wa'     => (string)($this->session->userdata('member_wa') ?? ''),
        ];

        $this->load->view('part/topnav', $data);
        $this->load->view('member/isi_pesanan', $data);
        $this->load->view('part/footer', $data);
    }

    public function submit()
    {
        $member_id = (int)$this->session->userdata('member_id');

        $nama   = trim((string)$this->input->post('nama', true));
        $alamat = trim((string)$this->input->post('alamat', true));
        $no_wa  = trim((string)$this->input->post('no_wa', true));

        if ($nama === '' || $alamat === '' || $no_wa === '') {
            $this->session->set_flashdata('pesan_gagal', 'Nama, alamat, dan nomor WA wajib diisi.');
            redirect('member/isi_pesanan');
        }

        // normalisasi no_wa supaya konsisten (menghindari +62 vs 0 vs spasi/strip)
        $no_wa_norm = preg_replace('/[\s\.\-]+/', '', $no_wa);
        if (strpos($no_wa_norm, '+62') === 0) $no_wa_norm = '0' . substr($no_wa_norm, 3);
        if (strpos($no_wa_norm, '62') === 0)  $no_wa_norm = '0' . substr($no_wa_norm, 2);

        if (!$this->pesan->cart_has_items()) {
            $this->session->set_flashdata('pesan_gagal', 'Keranjang masih kosong.');
            redirect('member/isi_pesanan');
        }

        $res = $this->pesan->checkout($member_id, [
            'nama'   => $nama,
            'alamat' => $alamat,
            'no_wa'  => $no_wa_norm,
        ]);

        if (!empty($res['ok'])) {
            $this->session->set_userdata('member_alamat', $alamat);
            $this->session->set_userdata('member_wa', $no_wa_norm);

            $id_pesanan = (int)($res['id_pesanan'] ?? 0);

            $this->session->set_flashdata('pesan_berhasil', 'Pesanan berhasil dibuat. ID: '.$id_pesanan);

            redirect('member/pembayaran/index/'.$id_pesanan);
        }

        $this->session->set_flashdata('pesan_gagal', $res['msg'] ?? 'Gagal membuat pesanan.');
        redirect('member/isi_pesanan');
    }
}
