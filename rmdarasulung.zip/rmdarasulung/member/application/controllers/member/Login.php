<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();

        date_default_timezone_set('Asia/Jakarta');
        $this->load->library(['session', 'form_validation']);
        $this->load->helper(['url', 'form']);
        $this->load->database();

        $this->load->model('member/Mlogin', 'mlogin');
    }

    public function index()
    {
        if ($this->session->userdata('member_id')) {
            redirect('member/dashboard');
        }

        if ($this->input->method() === 'post') {

            $this->form_validation->set_rules('username', 'Username', 'required|trim');
            $this->form_validation->set_rules('password', 'Password', 'required');

            if ($this->form_validation->run() === TRUE) {

                $username = trim((string)$this->input->post('username', true));
                $password = (string)$this->input->post('password', true);

                $u = $this->mlogin->get_by_username($username);

                if ($u && password_verify($password, $u->password)) {

                    $this->session->set_userdata([
                        'member_id'       => (int)$u->id_user,
                        'member_username' => (string)$u->username,
                        'member_nama'     => (string)$u->nama_user,
                    ]);

                    redirect('member/dashboard');
                }

                $this->session->set_flashdata('member_error', 'Username atau password salah.');
                redirect('member/login');
            }
        }

        $this->load->view('member/login');

    }

    public function logout()
    {
        $this->session->unset_userdata(['member_id', 'member_username', 'member_nama']);
        $this->session->sess_destroy();
        redirect('member/login');
    }
}
    