<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tracking_pesanan extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        date_default_timezone_set('Asia/Jakarta');

        $this->load->library('session');
        $this->load->helper(['url']);
        $this->load->database();

        $this->load->model('member/Mtracking_pesanan', 'trk');
    }

    public function lihat($id_pesanan = null)
    {
       
        $member_id = (int)$this->session->userdata('member_id');
        if ($member_id <= 0) {
            redirect('member/login');
        }

        $target_id = $this->trk->resolve_pesanan_id($member_id, $id_pesanan);

        $data = [
            'id_pesanan'   => (int)$target_id,
            'status'       => $target_id ? $this->trk->get_status($target_id) : '',
            'timeline'     => $target_id ? $this->trk->get_timeline($target_id) : [],
            'items'        => $target_id ? $this->trk->get_items($target_id) : [],
            'pesan_kosong' => $target_id ? '' : 'Belum ada pesanan untuk ditampilkan.'
        ];

        $this->load->view('member/tracking_pesanan_view', $data);
    }

    public function count_json()
    {
        // FIX: jangan redirect, cukup return 0 jika belum login
        $member_id = (int)$this->session->userdata('member_id');
        if ($member_id <= 0) {
            return $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode(['count' => 0]));
        }

        $count = (int)$this->trk->count_badge($member_id);

        return $this->output
            ->set_content_type('application/json')
            ->set_output(json_encode(['count' => $count]));
    }


    public function panel_html($id_pesanan = null)
    {
        $member_id = (int)$this->session->userdata('member_id');
        if ($member_id <= 0) {
            $this->output->set_status_header(401);
            return $this->output
                ->set_content_type('text/plain')
                ->set_output('UNAUTHORIZED');
        }

        $target_id = $this->trk->resolve_pesanan_id($member_id, $id_pesanan);

        $data = [
            'id_pesanan'   => (int)$target_id,
            'status'       => $target_id ? $this->trk->get_status($target_id) : '',
            'timeline'     => $target_id ? $this->trk->get_timeline($target_id) : [],
            'items'        => $target_id ? $this->trk->get_items($target_id) : [],
            'pesan_kosong' => $target_id ? '' : 'Belum ada pesanan untuk ditampilkan.',
        ];

        $this->load->view('member/tracking_pesanan_panel', $data);
    }

}
