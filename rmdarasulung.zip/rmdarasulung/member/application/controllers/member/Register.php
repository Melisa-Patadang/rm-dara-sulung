<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();

        date_default_timezone_set('Asia/Jakarta');
        $this->load->library(['session', 'form_validation']);
        $this->load->helper(['url', 'form']);
        $this->load->database();

        $this->load->model('member/Mregister', 'mregister');
    }

    public function index()
    {
    
        if ($this->session->userdata('member_id')) {
            redirect('dashboard'); 
        }

        if ($this->input->method() === 'post') {

            $this->form_validation->set_rules('username', 'Username', 'required|trim|min_length[3]|max_length[50]');
            $this->form_validation->set_rules('nama_user', 'Nama', 'required|trim|min_length[2]|max_length[100]');
            $this->form_validation->set_rules('email', 'Email', 'required|trim|valid_email|max_length[100]');
            $this->form_validation->set_rules('nomor', 'No WA', 'required|trim|min_length[8]|max_length[30]');
            $this->form_validation->set_rules('password', 'Password', 'required|min_length[5]');

            if ($this->form_validation->run() === TRUE) {

                $username  = trim((string)$this->input->post('username', true));
                $nama_user = trim((string)$this->input->post('nama_user', true));
                $email     = trim((string)$this->input->post('email', true));
                $nomor     = trim((string)$this->input->post('nomor', true));
                $password  = (string)$this->input->post('password', true);

                if ($this->mregister->username_exists($username)) {
                    $this->session->set_flashdata('member_error', 'Username sudah dipakai.');
                    redirect('register'); 
                }

                if ($this->mregister->email_exists($email)) {
                    $this->session->set_flashdata('member_error', 'Email sudah dipakai.');
                    redirect('register');
                }

                $ok = $this->mregister->create_member([
                    'username'  => $username,
                    'nama_user' => $nama_user,
                    'email'     => $email,
                    'nomor'     => $nomor,
                    'password'  => password_hash($password, PASSWORD_BCRYPT),
                ]);

                if ($ok) {
                    $this->session->set_flashdata('member_success', 'Registrasi berhasil. Silakan login.');
                    redirect('login'); 
                }

                $this->session->set_flashdata('member_error', 'Registrasi gagal. Coba lagi.');
                redirect('register');
            }
        }

        $this->load->view('member/register');
    }
}
