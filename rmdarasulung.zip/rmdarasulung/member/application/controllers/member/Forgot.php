<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Forgot extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        date_default_timezone_set('Asia/Jakarta');

        $this->load->library(['session','form_validation']);
        $this->load->helper(['url','form']);
        $this->load->database();

        $this->load->model('member/Mforgot', 'mforgot');
    }

    public function index()
    {
        if ($this->input->method() === 'post') {

            $step = (string)$this->input->post('step', true);

            if ($step === 'request_otp') {
                $this->form_validation->set_rules('email', 'Email', 'required|trim|valid_email');
                if ($this->form_validation->run() === TRUE) {
                    $email = trim((string)$this->input->post('email', true));
                    $this->mforgot->request_otp($email);
                    redirect('forgot');
                }
            }

            if ($step === 'reset_password') {
                $this->form_validation->set_rules('otp', 'OTP', 'required|trim|exact_length[6]');
                $this->form_validation->set_rules('password', 'Password', 'required|min_length[5]');
                $this->form_validation->set_rules('password2', 'Konfirmasi Password', 'required|matches[password]');

                if ($this->form_validation->run() === TRUE) {
                    $otp  = trim((string)$this->input->post('otp', true));
                    $pass = (string)$this->input->post('password', true);

                    $ok = $this->mforgot->reset_with_otp($otp, $pass);

                    if ($ok) {
                        redirect('login');
                    }
                    redirect('forgot');
                }
            }
        }

        $this->load->view('member/forgot');
    }
}
