<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        date_default_timezone_set('Asia/Jakarta');

        $this->load->library('session');
        $this->load->helper(['url']);
        $this->load->database();
        $this->load->model('Mdashboard', 'dash');

     
        if (!$this->session->userdata('member_id')) {
            redirect('member/login');
        }
    }

    public function index()
    {
        $data = [
            'nama' => (string)$this->session->userdata('member_nama'),
        ];

        $this->load->view('part/topnav', $data);
        $this->load->view('member/dashboard', $data);
        $this->load->view('part/footer', $data);
    }
}
